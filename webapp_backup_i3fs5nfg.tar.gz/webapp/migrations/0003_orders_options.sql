-- Order codes like "czs1", customer-facing tracking, and per-item customization options
ALTER TABLE orders ADD COLUMN order_code TEXT;
ALTER TABLE orders ADD COLUMN customer_phone TEXT DEFAULT '';
ALTER TABLE orders ADD COLUMN notes TEXT DEFAULT '';
ALTER TABLE orders ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE order_items ADD COLUMN sticker_type TEXT DEFAULT 'regular';
ALTER TABLE order_items ADD COLUMN sticker_size TEXT DEFAULT '6-8';
ALTER TABLE order_items ADD COLUMN notes TEXT DEFAULT '';

CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_code ON orders(order_code);
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(customer_email);

-- Migrate legacy English statuses to the new workflow
UPDATE orders SET status = 'designing' WHERE status = 'pending';
UPDATE orders SET status = 'delivering' WHERE status = 'shipped';
UPDATE orders SET order_code = 'czs' || id WHERE order_code IS NULL;
