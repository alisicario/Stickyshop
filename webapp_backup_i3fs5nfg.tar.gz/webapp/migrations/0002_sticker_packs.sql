-- Products are sticker packs: add a second "pack contents" image shown in the details view
ALTER TABLE stickers ADD COLUMN detail_image_url TEXT DEFAULT '';
