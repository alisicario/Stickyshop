import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import {
  type Bindings,
  getAdminPassword,
  createSessionToken,
  setSessionCookie,
  clearSessionCookie,
  isAdmin,
  requireAdmin
} from './auth'
import { renderPage } from './page'
import {
  STICKER_TYPES,
  STICKER_SIZES,
  ORDER_STATUSES,
  TYPE_IDS,
  SIZE_IDS,
  STATUS_IDS,
  EDITABLE_STATUS,
  ORDER_CODE_PREFIX
} from './options'

const app = new Hono<{ Bindings: Bindings }>()

app.use('/api/*', cors())
app.use('/static/*', serveStatic({ root: './public' }))

// ---------- Sticker pack validation ----------
type StickerInput = {
  name?: string
  description?: string
  price?: number | string
  image_url?: string
  detail_image_url?: string
  category?: string
  stock?: number | string
  is_active?: boolean | number
}

const IMAGE_URL_RE = /^(https?:\/\/|data:image\/|\/static\/|\/images\/)/i

function validateSticker(body: StickerInput, partial = false) {
  const errors: string[] = []
  const out: Record<string, unknown> = {}

  if (body.name !== undefined || !partial) {
    const name = String(body.name ?? '').trim()
    if (!name) errors.push('اسم الباقة مطلوب.')
    else if (name.length > 100) errors.push('يجب أن يكون الاسم أقل من 100 حرف.')
    out.name = name
  }
  if (body.description !== undefined || !partial) {
    out.description = String(body.description ?? '').trim().slice(0, 1000)
  }
  if (body.price !== undefined || !partial) {
    const price = Number(body.price)
    if (!Number.isFinite(price) || price < 0) errors.push('السعر يجب أن يكون رقماً غير سالب.')
    out.price = Math.round(price * 100) / 100
  }
  if (body.image_url !== undefined || !partial) {
    const url = String(body.image_url ?? '').trim()
    if (!url) errors.push('صورة الغلاف مطلوبة.')
    else if (!IMAGE_URL_RE.test(url)) errors.push('رابط الصورة يجب أن يبدأ بـ http(s):// أو /images/ أو /static/.')
    else if (url.length > 2_000_000) errors.push('رابط الصورة طويل جداً. يرجى رفع الملف بدلاً من ذلك.')
    out.image_url = url
  }
  if (body.detail_image_url !== undefined || !partial) {
    const url = String(body.detail_image_url ?? '').trim()
    if (url && !IMAGE_URL_RE.test(url)) errors.push('رابط صورة محتويات الباقة يجب أن يبدأ بـ http(s):// أو /images/ أو /static/.')
    else if (url.length > 2_000_000) errors.push('رابط صورة المحتويات طويل جداً. يرجى رفع الملف بدلاً من ذلك.')
    out.detail_image_url = url
  }
  if (body.category !== undefined || !partial) {
    out.category = String(body.category ?? 'عام').trim().slice(0, 50) || 'عام'
  }
  if (body.stock !== undefined || !partial) {
    const stock = body.stock === undefined || body.stock === '' ? 100 : Number(body.stock)
    if (!Number.isInteger(stock) || stock < 0) errors.push('المخزون يجب أن يكون عدداً صحيحاً غير سالب.')
    out.stock = stock
  }
  if (body.is_active !== undefined) out.is_active = body.is_active ? 1 : 0
  else if (!partial) out.is_active = 1
  return { errors, data: out }
}

// ---------- Public catalog API ----------
const PUBLIC_COLS = 'id, name, description, price, image_url, detail_image_url, category, stock'

app.get('/api/options', (c) =>
  c.json({ types: STICKER_TYPES, sizes: STICKER_SIZES, statuses: ORDER_STATUSES, editableStatus: EDITABLE_STATUS, codePrefix: ORDER_CODE_PREFIX })
)

app.get('/api/stickers', async (c) => {
  const category = c.req.query('category')
  const q = c.req.query('q')
  let sql = `SELECT ${PUBLIC_COLS} FROM stickers WHERE is_active = 1`
  const params: unknown[] = []
  if (category && category !== 'All') {
    sql += ' AND category = ?'
    params.push(category)
  }
  if (q) {
    sql += ' AND (name LIKE ? OR description LIKE ?)'
    params.push(`%${q}%`, `%${q}%`)
  }
  sql += ' ORDER BY created_at DESC, id DESC'
  const { results } = await c.env.DB.prepare(sql).bind(...params).all()
  return c.json({ stickers: results })
})

app.get('/api/categories', async (c) => {
  const { results } = await c.env.DB
    .prepare('SELECT DISTINCT category FROM stickers WHERE is_active = 1 ORDER BY category')
    .all<{ category: string }>()
  return c.json({ categories: results.map((r) => r.category) })
})

app.get('/api/stickers/:id', async (c) => {
  const id = Number(c.req.param('id'))
  const sticker = await c.env.DB
    .prepare(`SELECT ${PUBLIC_COLS}, created_at FROM stickers WHERE id = ? AND is_active = 1`)
    .bind(id)
    .first()
  if (!sticker) return c.json({ error: 'الباقة غير موجودة' }, 404)
  return c.json({ sticker })
})

// ---------- Orders ----------
type OrderItemInput = { id: number; quantity: number; sticker_type?: string; sticker_size?: string; notes?: string }
type StickerRow = { id: number; name: string; price: number; stock: number }
type ValidatedLine = { sticker: StickerRow; qty: number; type: string; size: string; notes: string }
type OrderItemRow = { sticker_id: number; quantity: number }

const normalizeEmail = (e: string) => e.trim().toLowerCase()
const codeOf = (id: number) => `${ORDER_CODE_PREFIX}${id}`
const normalizeCode = (raw: string) => raw.trim().replace(/^#/, '').toLowerCase()

// Validate items against the DB: prices come from the DB, options must be in the catalog.
async function validateItems(db: D1Database, items: OrderItemInput[]): Promise<{ error?: string; lines: ValidatedLine[]; total: number }> {
  const fail = (error: string) => ({ error, lines: [], total: 0 })
  if (!Array.isArray(items) || items.length === 0) return fail('السلة فارغة.')
  const ids = [...new Set(items.map((i) => Number(i.id)).filter((n) => Number.isInteger(n)))]
  if (ids.length === 0) return fail('عناصر غير صالحة.')
  const placeholders = ids.map(() => '?').join(',')
  const { results: stickers } = await db
    .prepare(`SELECT id, name, price, stock FROM stickers WHERE is_active = 1 AND id IN (${placeholders})`)
    .bind(...ids)
    .all<StickerRow>()
  const byId = new Map(stickers.map((s) => [s.id, s]))

  const lines: ValidatedLine[] = []
  const needed = new Map<number, number>()
  for (const item of items) {
    const s = byId.get(Number(item.id))
    const qty = Number(item.quantity)
    if (!s) return fail(`الباقة #${item.id} لم تعد متوفرة.`)
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) return fail(`كمية غير صالحة لـ "${s.name}".`)
    const type = String(item.sticker_type ?? 'regular')
    const size = String(item.sticker_size ?? '6-8')
    if (!TYPE_IDS.includes(type)) return fail('نوع الملصق غير صالح.')
    if (!SIZE_IDS.includes(size)) return fail('قياس الملصق غير صالح.')
    const notes = String(item.notes ?? '').trim().slice(0, 1000)
    needed.set(s.id, (needed.get(s.id) ?? 0) + qty)
    lines.push({ sticker: s, qty, type, size, notes })
  }
  for (const [id, q] of needed) {
    const s = byId.get(id)!
    if (s.stock < q) return fail(`المتوفر من "${s.name}" هو ${s.stock} فقط.`)
  }
  const total = Math.round(lines.reduce((sum, l) => sum + l.sticker.price * l.qty, 0) * 100) / 100
  return { lines, total }
}

function validateCustomer(body: Record<string, unknown>) {
  const name = String(body.customer_name ?? '').trim().slice(0, 100)
  const email = normalizeEmail(String(body.customer_email ?? ''))
  const phone = String(body.customer_phone ?? '').trim().slice(0, 30)
  const address = String(body.shipping_address ?? '').trim().slice(0, 500)
  const notes = String(body.notes ?? '').trim().slice(0, 1000)
  if (!name || !email || !address) return { error: 'الاسم والبريد الإلكتروني وعنوان التوصيل مطلوبة.' } as const
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'البريد الإلكتروني غير صالح.' } as const
  return { name, email, phone, address, notes }
}

async function loadOrderWithItems(db: D1Database, code: string) {
  const order = await db.prepare('SELECT * FROM orders WHERE order_code = ?').bind(code).first<Record<string, unknown>>()
  if (!order) return null
  const { results: items } = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(order.id as number).all()
  return { ...order, items }
}

const itemInsert = (db: D1Database, orderId: number, l: ValidatedLine) =>
  db
    .prepare(
      'INSERT INTO order_items (order_id, sticker_id, sticker_name, unit_price, quantity, sticker_type, sticker_size, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    )
    .bind(orderId, l.sticker.id, l.sticker.name, l.sticker.price, l.qty, l.type, l.size, l.notes)
const stockDec = (db: D1Database, stickerId: number, qty: number) =>
  db.prepare('UPDATE stickers SET stock = MAX(stock - ?, 0) WHERE id = ?').bind(qty, stickerId)
const stockInc = (db: D1Database, stickerId: number, qty: number) =>
  db.prepare('UPDATE stickers SET stock = stock + ? WHERE id = ?').bind(qty, stickerId)

// Place an order (checkout) → returns order_code like "czs12"
app.post('/api/orders', async (c) => {
  const body = await c.req.json<Record<string, unknown>>().catch(() => ({}))
  const cust = validateCustomer(body)
  if ('error' in cust) return c.json({ error: cust.error }, 400)
  const v = await validateItems(c.env.DB, (body.items as OrderItemInput[]) ?? [])
  if (v.error) return c.json({ error: v.error }, 400)

  const orderRes = await c.env.DB
    .prepare(
      'INSERT INTO orders (customer_name, customer_email, customer_phone, shipping_address, notes, total, status) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .bind(cust.name, cust.email, cust.phone, cust.address, cust.notes, v.total, 'designing')
    .run()
  const orderId = orderRes.meta.last_row_id as number
  const code = codeOf(orderId)

  await c.env.DB.batch([
    c.env.DB.prepare('UPDATE orders SET order_code = ? WHERE id = ?').bind(code, orderId),
    ...v.lines.flatMap((l) => [itemInsert(c.env.DB, orderId, l), stockDec(c.env.DB, l.sticker.id, l.qty)])
  ])

  return c.json({ success: true, order_id: orderId, order_code: code, total: v.total }, 201)
})

// Customer: list my orders by email
app.get('/api/my-orders', async (c) => {
  const email = normalizeEmail(c.req.query('email') ?? '')
  if (!email) return c.json({ error: 'البريد الإلكتروني مطلوب.' }, 400)
  const { results: orders } = await c.env.DB
    .prepare('SELECT * FROM orders WHERE lower(customer_email) = ? ORDER BY created_at DESC LIMIT 50')
    .bind(email)
    .all<{ id: number }>()
  if (orders.length === 0) return c.json({ orders: [] })
  const ph = orders.map(() => '?').join(',')
  const { results: items } = await c.env.DB
    .prepare(`SELECT * FROM order_items WHERE order_id IN (${ph})`)
    .bind(...orders.map((o) => o.id))
    .all<{ order_id: number }>()
  return c.json({ orders: orders.map((o) => ({ ...o, items: items.filter((i) => i.order_id === o.id) })) })
})

// Customer: track a single order by code + email
app.get('/api/orders/:code', async (c) => {
  const code = normalizeCode(c.req.param('code'))
  const email = normalizeEmail(c.req.query('email') ?? '')
  if (!email) return c.json({ error: 'البريد الإلكتروني مطلوب.' }, 400)
  const order = await loadOrderWithItems(c.env.DB, code)
  if (!order || String(order.customer_email).toLowerCase() !== email)
    return c.json({ error: 'لم نجد طلباً بهذا الرقم والبريد الإلكتروني.' }, 404)
  return c.json({ order, canEdit: order.status === EDITABLE_STATUS })
})

// Customer: edit order (only while "designing"). Replaces items + shipping details, fixes stock.
app.put('/api/orders/:code', async (c) => {
  const code = normalizeCode(c.req.param('code'))
  const body = await c.req.json<Record<string, unknown>>().catch(() => ({}))
  const email = normalizeEmail(String(body.customer_email ?? ''))
  const order = await loadOrderWithItems(c.env.DB, code)
  if (!order || String(order.customer_email).toLowerCase() !== email)
    return c.json({ error: 'لم نجد طلباً بهذا الرقم والبريد الإلكتروني.' }, 404)
  if (order.status !== EDITABLE_STATUS) return c.json({ error: 'لا يمكن تعديل الطلب إلا وهو في مرحلة "قيد التصميم".' }, 409)

  const cust = validateCustomer({ ...body, customer_email: email })
  if ('error' in cust) return c.json({ error: cust.error }, 400)

  const oldItems = order.items as OrderItemRow[]
  const orderId = order.id as number
  // Temporarily restore old stock so availability is validated correctly
  if (oldItems.length) await c.env.DB.batch(oldItems.map((i) => stockInc(c.env.DB, i.sticker_id, i.quantity)))
  const v = await validateItems(c.env.DB, (body.items as OrderItemInput[]) ?? [])
  if (v.error) {
    if (oldItems.length) await c.env.DB.batch(oldItems.map((i) => stockDec(c.env.DB, i.sticker_id, i.quantity)))
    return c.json({ error: v.error }, 400)
  }

  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM order_items WHERE order_id = ?').bind(orderId),
    c.env.DB
      .prepare(
        'UPDATE orders SET customer_name = ?, customer_phone = ?, shipping_address = ?, notes = ?, total = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
      )
      .bind(cust.name, cust.phone, cust.address, cust.notes, v.total, orderId),
    ...v.lines.flatMap((l) => [itemInsert(c.env.DB, orderId, l), stockDec(c.env.DB, l.sticker.id, l.qty)])
  ])
  const updated = await loadOrderWithItems(c.env.DB, code)
  return c.json({ success: true, order: updated, canEdit: true })
})

// Customer: cancel order (only while "designing"). Restores stock.
app.post('/api/orders/:code/cancel', async (c) => {
  const code = normalizeCode(c.req.param('code'))
  const body = await c.req.json<{ customer_email?: string }>().catch(() => ({}))
  const email = normalizeEmail(String(body.customer_email ?? ''))
  const order = await loadOrderWithItems(c.env.DB, code)
  if (!order || String(order.customer_email).toLowerCase() !== email)
    return c.json({ error: 'لم نجد طلباً بهذا الرقم والبريد الإلكتروني.' }, 404)
  if (order.status !== EDITABLE_STATUS) return c.json({ error: 'لا يمكن إلغاء الطلب إلا وهو في مرحلة "قيد التصميم".' }, 409)

  const items = order.items as OrderItemRow[]
  await c.env.DB.batch([
    c.env.DB.prepare("UPDATE orders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(order.id as number),
    ...items.map((i) => stockInc(c.env.DB, i.sticker_id, i.quantity))
  ])
  const updated = await loadOrderWithItems(c.env.DB, code)
  return c.json({ success: true, order: updated, canEdit: false })
})

// ---------- Admin auth ----------
app.post('/api/admin/login', async (c) => {
  const { password } = await c.req.json<{ password?: string }>().catch(() => ({ password: '' }))
  if (!password || password !== getAdminPassword(c.env)) return c.json({ error: 'كلمة المرور غير صحيحة.' }, 401)
  setSessionCookie(c, await createSessionToken(c.env))
  return c.json({ success: true })
})

app.post('/api/admin/logout', (c) => {
  clearSessionCookie(c)
  return c.json({ success: true })
})

app.get('/api/admin/me', async (c) => c.json({ isAdmin: await isAdmin(c) }))

// ---------- Images (R2) ----------
const MAX_IMAGE_BYTES = 10 * 1024 * 1024 // server hard limit; client compresses to ~1 MB
const IMAGE_TYPES: Record<string, string> = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/svg+xml': 'svg',
  'image/avif': 'avif'
}

app.get('/images/:key', async (c) => {
  const key = c.req.param('key')
  if (!/^[a-zA-Z0-9_-]+\.[a-z0-9]+$/.test(key)) return c.notFound()
  const obj = await c.env.IMAGES.get(key)
  if (!obj) return c.notFound()
  const headers = new Headers()
  obj.writeHttpMetadata(headers)
  headers.set('etag', obj.httpEtag)
  headers.set('Cache-Control', 'public, max-age=31536000, immutable')
  return new Response(obj.body, { headers })
})

app.post('/api/admin/upload', requireAdmin, async (c) => {
  const form = await c.req.formData().catch(() => null)
  const file = form?.get('file')
  if (!(file instanceof File)) return c.json({ error: 'لم يتم رفع أي ملف.' }, 400)
  const ext = IMAGE_TYPES[file.type]
  if (!ext) return c.json({ error: 'نوع الصورة غير مدعوم. استخدم PNG أو JPG أو WebP أو GIF أو AVIF أو SVG.' }, 400)
  if (file.size > MAX_IMAGE_BYTES) return c.json({ error: 'الصورة كبيرة جداً (الحد الأقصى 10 ميغابايت).' }, 413)

  const key = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`
  await c.env.IMAGES.put(key, file.stream(), {
    httpMetadata: { contentType: file.type },
    customMetadata: { originalName: file.name.slice(0, 200) }
  })
  return c.json({ success: true, url: `/images/${key}`, size: file.size }, 201)
})

// ---------- Admin CRUD (protected) ----------
app.use('/api/admin/stickers/*', requireAdmin)
app.use('/api/admin/stickers', requireAdmin)
app.use('/api/admin/orders/*', requireAdmin)
app.use('/api/admin/orders', requireAdmin)

app.get('/api/admin/stickers', async (c) => {
  const { results } = await c.env.DB.prepare('SELECT * FROM stickers ORDER BY created_at DESC, id DESC').all()
  return c.json({ stickers: results })
})

app.post('/api/admin/stickers', async (c) => {
  const body = await c.req.json<StickerInput>().catch(() => ({}))
  const { errors, data } = validateSticker(body)
  if (errors.length) return c.json({ error: errors.join(' ') }, 400)
  const res = await c.env.DB
    .prepare(
      'INSERT INTO stickers (name, description, price, image_url, detail_image_url, category, stock, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    )
    .bind(data.name, data.description, data.price, data.image_url, data.detail_image_url, data.category, data.stock, data.is_active)
    .run()
  const sticker = await c.env.DB.prepare('SELECT * FROM stickers WHERE id = ?').bind(res.meta.last_row_id).first()
  return c.json({ success: true, sticker }, 201)
})

app.put('/api/admin/stickers/:id', async (c) => {
  const id = Number(c.req.param('id'))
  const existing = await c.env.DB.prepare('SELECT id FROM stickers WHERE id = ?').bind(id).first()
  if (!existing) return c.json({ error: 'الباقة غير موجودة' }, 404)
  const body = await c.req.json<StickerInput>().catch(() => ({}))
  const { errors, data } = validateSticker(body, true)
  if (errors.length) return c.json({ error: errors.join(' ') }, 400)
  const keys = Object.keys(data)
  if (keys.length === 0) return c.json({ error: 'لا يوجد ما يتم تحديثه.' }, 400)
  await c.env.DB
    .prepare(`UPDATE stickers SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
    .bind(...keys.map((k) => data[k]), id)
    .run()
  const sticker = await c.env.DB.prepare('SELECT * FROM stickers WHERE id = ?').bind(id).first()
  return c.json({ success: true, sticker })
})

app.delete('/api/admin/stickers/:id', async (c) => {
  const id = Number(c.req.param('id'))
  const existing = await c.env.DB
    .prepare('SELECT image_url, detail_image_url FROM stickers WHERE id = ?')
    .bind(id)
    .first<{ image_url: string; detail_image_url: string | null }>()
  if (!existing) return c.json({ error: 'الباقة غير موجودة' }, 404)
  await c.env.DB.prepare('DELETE FROM stickers WHERE id = ?').bind(id).run()
  for (const url of [existing.image_url, existing.detail_image_url]) {
    if (url && url.startsWith('/images/')) await c.env.IMAGES.delete(url.slice('/images/'.length)).catch(() => {})
  }
  return c.json({ success: true })
})

app.get('/api/admin/orders', async (c) => {
  const { results: orders } = await c.env.DB.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 200').all<{ id: number }>()
  if (orders.length === 0) return c.json({ orders: [] })
  const ph = orders.map(() => '?').join(',')
  const { results: items } = await c.env.DB
    .prepare(`SELECT * FROM order_items WHERE order_id IN (${ph})`)
    .bind(...orders.map((o) => o.id))
    .all<{ order_id: number }>()
  return c.json({ orders: orders.map((o) => ({ ...o, items: items.filter((i) => i.order_id === o.id) })) })
})

app.put('/api/admin/orders/:id', async (c) => {
  const id = Number(c.req.param('id'))
  const { status } = await c.req.json<{ status?: string }>().catch(() => ({ status: '' }))
  if (!status || !STATUS_IDS.includes(status)) return c.json({ error: 'حالة غير صالحة.' }, 400)
  const order = await c.env.DB.prepare('SELECT id, status FROM orders WHERE id = ?').bind(id).first<{ id: number; status: string }>()
  if (!order) return c.json({ error: 'الطلب غير موجود' }, 404)
  if (order.status === status) return c.json({ success: true })

  const stmts = [c.env.DB.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(status, id)]
  const { results: items } = await c.env.DB
    .prepare('SELECT sticker_id, quantity FROM order_items WHERE order_id = ?')
    .bind(id)
    .all<OrderItemRow>()
  // Cancelling returns stock; un-cancelling takes it again
  if (status === 'cancelled') stmts.push(...items.map((i) => stockInc(c.env.DB, i.sticker_id, i.quantity)))
  else if (order.status === 'cancelled') stmts.push(...items.map((i) => stockDec(c.env.DB, i.sticker_id, i.quantity)))
  await c.env.DB.batch(stmts)
  return c.json({ success: true })
})

// ---------- Pages (SPA shell) ----------
app.get('/favicon.ico', (c) => c.redirect('/static/favicon.svg'))
for (const path of ['/', '/admin', '/pack/:id', '/orders', '/orders/:code']) {
  app.get(path, (c) => c.html(renderPage()))
}

export default app
