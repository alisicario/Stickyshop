// Shared product options (server-side source of truth; also served to the frontend)

export const STICKER_TYPES = [
  { id: 'regular', label: 'ملصق عادي', desc: 'جودة عالية، دقة ممتازة' },
  { id: 'durable', label: 'ملصق مقاوم', desc: 'مقاوم للماء والخدوش ولا يترك أثراً عند الإزالة' },
  { id: 'transparent', label: 'ملصق شفاف', desc: 'يظهر بشكل شفاف، مقاوم للماء' },
  { id: 'hologram', label: 'ملصق هولوغرام', desc: 'لمعة ملونة، مقاوم للماء' }
] as const

export const STICKER_SIZES = [
  { id: '3-5', label: '٣-٥ سم' },
  { id: '6-8', label: '٦-٨ سم' },
  { id: '9-12', label: '٩-١٢ سم' },
  { id: '13-15', label: '١٣-١٥ سم' },
  { id: '18-26', label: '١٨-٢٦ سم' }
] as const

export const ORDER_STATUSES = [
  { id: 'designing', label: 'قيد التصميم', icon: 'fa-pen-ruler', color: 'brand' },
  { id: 'preparing', label: 'قيد التجهيز', icon: 'fa-box-open', color: 'amber' },
  { id: 'delivering', label: 'قيد التوصيل', icon: 'fa-truck', color: 'sky' },
  { id: 'delivered', label: 'تم التسليم', icon: 'fa-circle-check', color: 'green' },
  { id: 'cancelled', label: 'تم الإلغاء', icon: 'fa-circle-xmark', color: 'slate' }
] as const

export type StickerTypeId = (typeof STICKER_TYPES)[number]['id']
export type StickerSizeId = (typeof STICKER_SIZES)[number]['id']
export type OrderStatusId = (typeof ORDER_STATUSES)[number]['id']

export const TYPE_IDS = STICKER_TYPES.map((t) => t.id) as string[]
export const SIZE_IDS = STICKER_SIZES.map((s) => s.id) as string[]
export const STATUS_IDS = ORDER_STATUSES.map((s) => s.id) as string[]

// Only orders still in design can be edited or cancelled by the customer
export const EDITABLE_STATUS: OrderStatusId = 'designing'

export const ORDER_CODE_PREFIX = 'czs'
