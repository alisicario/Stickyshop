export function renderPage(): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ستيكي شوب — باقات ملصقات لكل الأذواق</title>
  <meta name="description" content="تسوّق باقات ملصقات فينيل عالية الجودة للابتوب، القوارير، الدفاتر والمزيد.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { sans: ['Cairo', 'system-ui', 'sans-serif'] },
          colors: {
            brand: {
              DEFAULT: '#32B19C',
              50: '#EAF8F5',
              100: '#D1F0EA',
              200: '#A6E1D6',
              300: '#79D1C1',
              400: '#4FC0AD',
              500: '#32B19C',
              600: '#2A9683',
              700: '#227A6B',
              800: '#1A5E52',
              900: '#12423A',
              dark: '#2A9683',
              light: '#79D1C1'
            }
          }
        }
      }
    }
  </script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
  <link href="/static/styles.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-b from-white via-brand-50 to-white text-slate-800 min-h-screen flex flex-col font-sans">

  <header id="site-header" class="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-brand-100 shadow-sm">
    <nav class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4" aria-label="القائمة الرئيسية">
      <a href="/" id="brand-link" class="flex items-center gap-2 text-2xl font-black text-brand-700">
        <i class="fas fa-note-sticky rotate-[8deg] text-brand"></i>
        <span>ستيكي <span class="text-brand">شوب</span></span>
      </a>
      <div class="flex items-center gap-2 sm:gap-3">
        <button id="my-orders-button" class="flex items-center gap-2 px-3 py-2 rounded-full border border-brand-200 text-brand-800 text-sm font-semibold hover:bg-brand-50 transition" title="طلباتي">
          <i class="fas fa-receipt"></i><span class="hidden sm:inline">طلباتي</span>
        </button>
        <button id="admin-button" class="hidden items-center gap-2 px-3 py-2 rounded-full bg-brand-800 text-white text-sm font-semibold hover:bg-brand-900 transition" title="لوحة المشرف">
          <i class="fas fa-user-shield"></i><span class="hidden sm:inline">المشرف</span>
        </button>
        <button id="cart-button" class="relative flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700 transition shadow-md shadow-brand/30">
          <i class="fas fa-shopping-bag"></i><span class="hidden sm:inline">السلة</span>
          <span id="cart-count" class="absolute -top-2 -left-2 bg-white text-brand-700 border-2 border-brand text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center hidden">0</span>
        </button>
      </div>
    </nav>
  </header>

  <main id="app" class="flex-1 max-w-6xl w-full mx-auto px-4 py-6"></main>

  <footer id="site-footer" class="border-t border-brand-100 bg-white/70 mt-10">
    <div class="max-w-6xl mx-auto px-4 py-6 text-sm text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
      <p>&copy; <span id="footer-year"></span> ستيكي شوب. جميع الحقوق محفوظة.</p>
      <button id="admin-login-link" class="text-slate-400 hover:text-brand-700 text-xs flex items-center gap-1">
        <i class="fas fa-lock"></i> دخول المشرف
      </button>
    </div>
  </footer>

  <!-- Cart drawer (slides in from the left in RTL) -->
  <aside id="cart-drawer" class="fixed inset-y-0 left-0 w-full max-w-md bg-white shadow-2xl z-50 -translate-x-full transition-transform duration-300 flex flex-col" aria-label="سلة التسوق">
    <header class="flex items-center justify-between px-5 py-4 border-b">
      <h2 class="text-xl font-bold"><i class="fas fa-shopping-bag text-brand ml-2"></i>سلة التسوق</h2>
      <button id="cart-close" class="text-slate-500 hover:text-slate-800 text-xl" aria-label="إغلاق السلة"><i class="fas fa-times"></i></button>
    </header>
    <section id="cart-items" class="flex-1 overflow-y-auto px-5 py-4 space-y-4"></section>
    <footer class="border-t px-5 py-4 space-y-3">
      <div class="flex justify-between text-lg font-bold"><span>الإجمالي</span><span id="cart-total">0.00 $</span></div>
      <button id="checkout-button" class="w-full py-3 rounded-xl bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700 disabled:opacity-40 disabled:cursor-not-allowed transition">
        <i class="fas fa-credit-card ml-2"></i>إتمام الطلب
      </button>
    </footer>
  </aside>
  <div id="drawer-backdrop" class="fixed inset-0 bg-black/40 z-40 hidden"></div>

  <!-- Generic modal -->
  <div id="modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div id="modal-backdrop" class="absolute inset-0 bg-black/50"></div>
    <div id="modal-panel" class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"></div>
  </div>

  <div id="toast" class="fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] px-5 py-3 rounded-full bg-brand-800 text-white text-sm font-medium shadow-lg opacity-0 pointer-events-none transition-opacity"></div>

  <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
  <script src="/static/app.js"></script>
  <script src="/static/pages.js"></script>
  <script src="/static/admin.js"></script>
</body>
</html>`
}
