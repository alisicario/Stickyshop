// Simple, stateless admin session using an HMAC-signed cookie (Web Crypto only).
import type { Context, Next } from 'hono'
import { getCookie, setCookie, deleteCookie } from 'hono/cookie'

export type Bindings = {
  DB: D1Database
  IMAGES: R2Bucket
  ADMIN_PASSWORD?: string
  SESSION_SECRET?: string
}

export const COOKIE_NAME = 'admin_session'
const SESSION_TTL_SECONDS = 60 * 60 * 12 // 12 hours

const DEFAULT_PASSWORD = 'admin123'

export function getAdminPassword(env: Bindings): string {
  return env.ADMIN_PASSWORD || DEFAULT_PASSWORD
}

function getSecret(env: Bindings): string {
  // Fall back to a value derived from the password so it still works without config.
  return env.SESSION_SECRET || `secret:${getAdminPassword(env)}:sticker-shop`
}

function toBase64Url(bytes: ArrayBuffer): string {
  const bin = String.fromCharCode(...new Uint8Array(bytes))
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

async function hmac(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message))
  return toBase64Url(sig)
}

export async function createSessionToken(env: Bindings): Promise<string> {
  const expires = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS
  const payload = `admin.${expires}`
  const sig = await hmac(getSecret(env), payload)
  return `${payload}.${sig}`
}

export async function verifySessionToken(env: Bindings, token: string | undefined): Promise<boolean> {
  if (!token) return false
  const parts = token.split('.')
  if (parts.length !== 3) return false
  const [role, expStr, sig] = parts
  if (role !== 'admin') return false
  const exp = parseInt(expStr, 10)
  if (!exp || exp < Math.floor(Date.now() / 1000)) return false
  const expected = await hmac(getSecret(env), `${role}.${expStr}`)
  if (expected.length !== sig.length) return false
  // constant-time-ish compare
  let diff = 0
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i)
  return diff === 0
}

export function setSessionCookie(c: Context, token: string) {
  setCookie(c, COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'Lax',
    path: '/',
    maxAge: SESSION_TTL_SECONDS,
    secure: new URL(c.req.url).protocol === 'https:'
  })
}

export function clearSessionCookie(c: Context) {
  deleteCookie(c, COOKIE_NAME, { path: '/' })
}

export async function isAdmin(c: Context<{ Bindings: Bindings }>): Promise<boolean> {
  return verifySessionToken(c.env, getCookie(c, COOKIE_NAME))
}

export async function requireAdmin(c: Context<{ Bindings: Bindings }>, next: Next) {
  if (!(await isAdmin(c))) {
    return c.json({ error: 'غير مصرح. يجب تسجيل دخول المشرف.' }, 401)
  }
  await next()
}
