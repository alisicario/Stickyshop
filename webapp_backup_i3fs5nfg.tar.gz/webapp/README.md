# ستيكي شوب (Sticky Shop) — متجر باقات الملصقات

## Project Overview
- **Name**: ستيكي شوب (`webapp`)
- **Language**: Arabic, RTL layout, Cairo font
- **Goal**: A lightweight online store for selling **sticker packs** (each product is a pack of multiple stickers). Customers customize sticker type & size per pack, place orders identified by a code (`#czs1`, `#czs2`, …), track status, and can edit/cancel while the order is still in design. A password-protected admin panel manages packs and order statuses.
- **Tech Stack**: Hono + TypeScript (Cloudflare Pages/Workers) · Cloudflare D1 (SQLite) · Cloudflare R2 (image storage) · TailwindCSS + Font Awesome + Axios via CDN
- **Theme**: brand teal `#32B19C` + white with gradient accents (`brand-50` … `brand-900`)

## URLs
- **Sandbox preview**: https://3000-i3fs5nfgayxh5cszpwnqa-ad490db5.sandbox.novita.ai
- **Pages**: `/` shop · `/pack/:id` pack details · `/orders` my orders · `/orders/:code` order tracking · `/admin` admin panel
- **Production**: not deployed yet

## Currently Completed Features
### Storefront (public, Arabic)
- Hero + responsive pack grid; category filter; live search; clickable cards
- **Pack details page** with big "what's inside" image + cover thumbnail, zoom lightbox, description, stock status, related packs
- **Customization options on each pack** (also editable later in the cart/order):
  - **نوع الملصقات** (radio cards): ملصق عادي · ملصق مقاوم · ملصق شفاف · ملصق هولوغرام (each with its description)
  - **قياس الملصقات** (slider with tick labels): ٣-٥ · ٦-٨ · ٩-١٢ · ١٣-١٥ · ١٨-٢٦ سم
  - **المزيد من التفاصيل**: free-text box for the customer's notes
- Cart drawer (persisted) — same pack with different options = separate lines; quantity controls
- Checkout: name, phone, email, address, order notes → order created with code **`#czs<N>`** (sequential)

### Orders (customer self-service)
- **طلباتي** (`/orders`): list all orders by email, or jump to a code directly
- **Order tracking page** (`/orders/:code`, verified by email): status timeline, items with chosen type/size/notes, customer & shipping info
- Statuses (set by admin, seen by customer): **قيد التصميم → قيد التجهيز → قيد التوصيل → تم التسليم**, plus **تم الإلغاء**
- **تعديل الطلب** — change quantities, type, size, notes, remove items, update shipping details. *Only while status is "قيد التصميم"*
- **الغاء الطلب** — *only while status is "قيد التصميم"*. Stock is restored automatically
- Email is remembered locally so returning customers see their orders instantly

### Admin (protected, Arabic)
- Footer "دخول المشرف" link → password login → "المشرف" button appears in header
- **Packs tab**: add/edit/delete/hide packs; two images per pack (cover + contents); eye icon opens public page
- **Image upload with automatic client-side compression to ≤ 1 MB** — PNG/WebP with transparency → WebP (alpha kept), JPEG → JPEG; iteratively lowers quality/dimensions until under 1 MB; shows bytes saved. Server accepts up to 10 MB as a safety net. Stored in R2.
- **Orders tab**: stats per status, filter by status, full order details incl. per-item options and notes, **status dropdown** (changes are visible to the customer immediately). Cancelling from admin restores stock; un-cancelling deducts it again.

## Admin Login
| Setting | Default (local) | Change |
|---|---|---|
| `ADMIN_PASSWORD` | `admin123` | `.dev.vars` locally; `npx wrangler pages secret put ADMIN_PASSWORD` in production |
| `SESSION_SECRET` | derived | same |

> **Change the default password before going public.**

## API Endpoints
### Public
| Method | Path | Description |
|---|---|---|
| GET | `/api/options` | Sticker types, sizes, order statuses, editable status, code prefix |
| GET | `/api/stickers?category=&q=` | Active packs |
| GET | `/api/stickers/:id` | Single pack |
| GET | `/api/categories` | Categories |
| GET | `/images/:key` | Uploaded image from R2 |
| POST | `/api/orders` | Create order `{customer_name, customer_email, customer_phone?, shipping_address, notes?, items:[{id, quantity, sticker_type, sticker_size, notes?}]}` → `{order_code}` |
| GET | `/api/my-orders?email=` | Orders for an email |
| GET | `/api/orders/:code?email=` | Track one order (`#` optional, case-insensitive) → `{order, canEdit}` |
| PUT | `/api/orders/:code` | Customer edit (409 unless status = `designing`) |
| POST | `/api/orders/:code/cancel` | Customer cancel (409 unless status = `designing`) |

### Admin (session cookie)
| Method | Path | Description |
|---|---|---|
| POST/POST/GET | `/api/admin/login` · `/logout` · `/me` | Auth |
| POST | `/api/admin/upload` | multipart `file` (≤10 MB) → `{url}` in R2 |
| GET/POST | `/api/admin/stickers` | List all / create |
| PUT/DELETE | `/api/admin/stickers/:id` | Update / delete (also deletes R2 images) |
| GET | `/api/admin/orders` | All orders with items |
| PUT | `/api/admin/orders/:id` | `{status}` ∈ designing, preparing, delivering, delivered, cancelled |

## Data Architecture
- **D1** (`DB`, `webapp-production`) · **R2** (`IMAGES`, `webapp-images`) · local dev uses `.wrangler/state/v3` emulation
- `stickers` (a row = a pack): name, description, price, image_url, detail_image_url, category, stock, is_active
- `orders`: **order_code** (`czs<id>`, unique), customer_name/email/phone, shipping_address, notes, total, **status**, created_at, updated_at
- `order_items`: order_id, sticker_id, sticker_name, unit_price, quantity, **sticker_type**, **sticker_size**, **notes**
- Option catalogs live in `src/options.ts` (single source of truth, served via `/api/options`)

## User Guide
**Customer**: browse → click a pack → choose type (cards), size (slider), write notes → set quantity → add to cart → checkout → receive `#czsN` → "طلباتي" to track; while "قيد التصميم" you can "تعديل الطلب" or "الغاء الطلب".

**Admin**: footer "دخول المشرف" → password → "المشرف" → **إضافة باقة** (upload images; compressed automatically) → **الطلبات** tab to change statuses.

## Local Development
```bash
npm run build
npm run db:reset            # migrations + Arabic seed packs
pm2 start ecosystem.config.cjs
```

## Deployment (Cloudflare Pages)
1. `npx wrangler d1 create webapp-production` → set `database_id` in `wrangler.jsonc`
2. `npx wrangler r2 bucket create webapp-images`
3. `npm run db:migrate:prod`
4. `npx wrangler pages project create webapp --production-branch main` → `npm run deploy:prod`
5. `npx wrangler pages secret put ADMIN_PASSWORD` / `SESSION_SECRET`
- **Status**: ❌ Not yet deployed

## Not Yet Implemented / Next Steps
- Online payment (Stripe / local gateways) — currently orders are placed without payment
- Email/WhatsApp notifications on status change
- Price differences per sticker type/size (all types currently same price)
- Customer accounts (currently email-based lookup)
- Pagination for large catalogs

## Last Updated
2026-09-22 (v4: Arabic RTL, ستيكي شوب, pack options, order codes, tracking, edit/cancel, image compression)
