/* ستيكي شوب — واجهة المتجر: الباقات، السلة، إتمام الطلب، متابعة الطلبات */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const app = $('#app');

  // ---------- State ----------
  const state = {
    stickers: [],
    categories: [],
    category: 'All',
    search: '',
    cart: JSON.parse(localStorage.getItem('cart_v2') || '[]'),
    isAdmin: false,
    view: 'shop',
    packId: null,
    orderCode: null,
    adminTab: 'packs',
    options: { types: [], sizes: [], statuses: [], editableStatus: 'designing', codePrefix: 'czs' },
    customerEmail: localStorage.getItem('customer_email') || ''
  };

  const money = (n) => Number(n).toFixed(2) + ' $';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const fmtDate = (d) => {
    if (!d) return '';
    const dt = new Date(d.replace(' ', 'T') + (d.endsWith('Z') ? '' : 'Z'));
    return isNaN(dt) ? d : dt.toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' });
  };
  const typeOf = (id) => state.options.types.find((t) => t.id === id) || { label: id, desc: '' };
  const sizeOf = (id) => state.options.sizes.find((s) => s.id === id) || { label: id };
  const statusOf = (id) => state.options.statuses.find((s) => s.id === id) || { label: id, icon: 'fa-circle', color: 'slate' };
  const codeLabel = (code) => `#${code}`;

  const STATUS_CLASSES = {
    brand: 'bg-brand-100 text-brand-800',
    amber: 'bg-amber-100 text-amber-800',
    sky: 'bg-sky-100 text-sky-800',
    green: 'bg-green-100 text-green-800',
    slate: 'bg-slate-200 text-slate-600'
  };
  const statusBadge = (id) => {
    const s = statusOf(id);
    return `<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${STATUS_CLASSES[s.color] || STATUS_CLASSES.slate}"><i class="fas ${s.icon}"></i>${esc(s.label)}</span>`;
  };

  // ---------- Routing ----------
  function parseRoute() {
    const p = location.pathname;
    let m;
    if ((m = p.match(/^\/pack\/(\d+)$/))) {
      state.view = 'pack';
      state.packId = Number(m[1]);
    } else if ((m = p.match(/^\/orders\/([a-zA-Z0-9]+)$/))) {
      state.view = 'order';
      state.orderCode = m[1].toLowerCase();
    } else if (p === '/orders') state.view = 'orders';
    else if (p === '/admin') state.view = 'admin';
    else state.view = 'shop';
  }
  parseRoute();

  function navigate(view, param = null) {
    state.view = view;
    if (view === 'pack') state.packId = param;
    if (view === 'order') state.orderCode = param;
    const path =
      view === 'admin' ? '/admin' : view === 'pack' ? `/pack/${param}` : view === 'orders' ? '/orders' : view === 'order' ? `/orders/${param}` : '/';
    if (location.pathname !== path) history.pushState({}, '', path);
    if (view !== 'pack') document.title = 'ستيكي شوب — باقات ملصقات لكل الأذواق';
    render();
  }
  window.addEventListener('popstate', () => {
    parseRoute();
    render();
  });

  // ---------- Toast & Modal ----------
  let toastTimer;
  function toast(msg, isError = false) {
    const t = $('#toast');
    t.textContent = msg;
    t.className = t.className.replace(/bg-\S+/g, '') + (isError ? ' bg-red-600' : ' bg-brand-800');
    t.style.opacity = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.style.opacity = '0'), 2800);
  }
  function openModal(html, wide = false) {
    $('#modal-panel').innerHTML = html;
    $('#modal-panel').classList.toggle('max-w-lg', !wide);
    $('#modal-panel').classList.toggle('max-w-2xl', wide);
    $('#modal').classList.remove('hidden');
    $('#modal').classList.add('flex');
  }
  function closeModal() {
    $('#modal').classList.add('hidden');
    $('#modal').classList.remove('flex');
    $('#modal-panel').innerHTML = '';
  }
  $('#modal-backdrop').addEventListener('click', closeModal);

  // ---------- Options UI (type radios + size slider + notes) ----------
  // Renders the customization block. `prefix` keeps ids unique per instance.
  function optionsHtml(prefix, selected = {}) {
    const type = selected.sticker_type || 'regular';
    const sizeIdx = Math.max(0, state.options.sizes.findIndex((s) => s.id === (selected.sticker_size || '6-8')));
    return `
      <div class="options-block space-y-5" data-prefix="${prefix}">
        <fieldset>
          <legend class="font-bold text-slate-800 mb-2"><i class="fas fa-swatchbook text-brand ml-1"></i>نوع الملصقات</legend>
          <div class="grid sm:grid-cols-2 gap-2">
            ${state.options.types
              .map(
                (t) => `<label class="type-option relative">
                  <input type="radio" name="${prefix}-type" value="${t.id}" ${t.id === type ? 'checked' : ''}>
                  <div class="type-card flex items-start gap-3">
                    <span class="type-check w-6 h-6 rounded-full bg-brand text-white flex items-center justify-center text-xs shrink-0 mt-0.5"><i class="fas fa-check"></i></span>
                    <span><span class="block font-bold text-slate-800">${esc(t.label)}</span><span class="block text-xs text-slate-500 leading-relaxed">${esc(t.desc)}</span></span>
                  </div></label>`
              )
              .join('')}
          </div>
        </fieldset>

        <fieldset>
          <legend class="font-bold text-slate-800 mb-1"><i class="fas fa-ruler-combined text-brand ml-1"></i>قياس الملصقات</legend>
          <div class="bg-brand-50/60 rounded-2xl p-4">
            <div class="flex items-center justify-between mb-3">
              <span class="text-sm text-slate-500">حرّك المؤشر لاختيار القياس</span>
              <span id="${prefix}-size-label" class="px-3 py-1 rounded-full bg-white border border-brand-200 text-brand-800 font-black text-lg">${esc(state.options.sizes[sizeIdx]?.label || '')}</span>
            </div>
            <input type="range" id="${prefix}-size" class="size-slider" min="0" max="${state.options.sizes.length - 1}" step="1" value="${sizeIdx}" aria-label="قياس الملصقات">
            <div id="${prefix}-ticks" class="size-ticks mt-2">
              ${state.options.sizes.map((s, i) => `<span class="size-tick ${i === sizeIdx ? 'active' : ''}" data-i="${i}">${esc(s.label)}</span>`).join('')}
            </div>
          </div>
        </fieldset>

        <label class="block">
          <span class="font-bold text-slate-800"><i class="fas fa-comment-dots text-brand ml-1"></i>المزيد من التفاصيل</span>
          <textarea id="${prefix}-notes" rows="3" maxlength="1000" class="mt-2 w-full border border-brand-100 rounded-xl px-3 py-2 text-sm" placeholder="اكتب هنا أي ملاحظات أو تفاصيل إضافية تريدها (ألوان، أسماء، أفكار تصميم...)">${esc(selected.notes || '')}</textarea>
        </label>
      </div>`;
  }
  function bindOptions(prefix) {
    const slider = $(`#${prefix}-size`);
    const label = $(`#${prefix}-size-label`);
    const ticks = $(`#${prefix}-ticks`);
    const update = () => {
      const i = Number(slider.value);
      label.textContent = state.options.sizes[i]?.label || '';
      ticks.querySelectorAll('.size-tick').forEach((t) => t.classList.toggle('active', Number(t.dataset.i) === i));
    };
    slider.addEventListener('input', update);
    ticks.addEventListener('click', (e) => {
      const t = e.target.closest('.size-tick');
      if (!t) return;
      slider.value = t.dataset.i;
      update();
    });
    return {
      value: () => ({
        sticker_type: (document.querySelector(`input[name="${prefix}-type"]:checked`) || {}).value || 'regular',
        sticker_size: state.options.sizes[Number(slider.value)]?.id || '6-8',
        notes: $(`#${prefix}-notes`).value.trim()
      })
    };
  }
  const optionsSummary = (l) =>
    `<span class="inline-flex flex-wrap gap-1 text-[11px]">
      <span class="px-2 py-0.5 rounded-full bg-brand-50 text-brand-800">${esc(typeOf(l.sticker_type).label)}</span>
      <span class="px-2 py-0.5 rounded-full bg-brand-50 text-brand-800">${esc(sizeOf(l.sticker_size).label)}</span>
    </span>${l.notes ? `<p class="text-[11px] text-slate-500 mt-1 line-clamp-2"><i class="fas fa-comment-dots ml-1"></i>${esc(l.notes)}</p>` : ''}`;

  // ---------- Cart ----------
  // Each line = pack + chosen options. Same pack with different options = separate lines.
  const lineKey = (l) => `${l.id}|${l.sticker_type}|${l.sticker_size}|${l.notes}`;
  function saveCart() {
    localStorage.setItem('cart_v2', JSON.stringify(state.cart));
    renderCartBadge();
    renderCart();
  }
  function addToCart(sticker, opts, qty = 1, silent = false) {
    const line = { id: sticker.id, name: sticker.name, price: sticker.price, image_url: sticker.image_url, ...opts, quantity: 0 };
    const key = lineKey(line);
    const existing = state.cart.find((l) => lineKey(l) === key);
    if (existing) existing.quantity = Math.min(99, existing.quantity + qty);
    else state.cart.push({ ...line, quantity: Math.min(99, qty) });
    saveCart();
    const badge = $('#cart-count');
    badge.classList.remove('pop');
    void badge.offsetWidth;
    badge.classList.add('pop');
    if (!silent) toast(`تمت إضافة "${sticker.name}" إلى السلة`);
  }
  function setQty(idx, qty) {
    const line = state.cart[idx];
    if (!line) return;
    line.quantity = qty;
    if (line.quantity <= 0) state.cart.splice(idx, 1);
    saveCart();
  }
  const cartTotal = () => state.cart.reduce((s, l) => s + l.price * l.quantity, 0);
  const cartCount = () => state.cart.reduce((s, l) => s + l.quantity, 0);

  function renderCartBadge() {
    const n = cartCount();
    const badge = $('#cart-count');
    badge.textContent = n;
    badge.classList.toggle('hidden', n === 0);
  }
  function renderCart() {
    const box = $('#cart-items');
    if (state.cart.length === 0) {
      box.innerHTML = `<div class="text-center text-slate-400 py-16"><i class="fas fa-shopping-bag text-5xl mb-4"></i><p>سلتك فارغة.</p></div>`;
    } else {
      box.innerHTML = state.cart
        .map(
          (l, i) => `
        <article class="cart-line flex gap-3 items-start" data-idx="${i}">
          <img src="${esc(l.image_url)}" alt="${esc(l.name)}" class="w-16 h-16 rounded-lg object-contain sticker-img border">
          <div class="flex-1 min-w-0">
            <h3 class="font-semibold truncate">${esc(l.name)}</h3>
            <p class="text-sm text-slate-500">${money(l.price)} للباقة</p>
            ${optionsSummary(l)}
          </div>
          <div class="flex flex-col items-end gap-2">
            <div class="flex items-center gap-1">
              <button class="qty-dec w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200" aria-label="تقليل">-</button>
              <span class="w-6 text-center font-medium">${l.quantity}</span>
              <button class="qty-inc w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200" aria-label="زيادة">+</button>
            </div>
            <button class="line-remove text-slate-400 hover:text-red-600 text-sm" aria-label="حذف"><i class="fas fa-trash"></i></button>
          </div>
        </article>`
        )
        .join('');
    }
    $('#cart-total').textContent = money(cartTotal());
    $('#checkout-button').disabled = state.cart.length === 0;
  }
  $('#cart-items').addEventListener('click', (e) => {
    const line = e.target.closest('.cart-line');
    if (!line) return;
    const idx = Number(line.dataset.idx);
    const l = state.cart[idx];
    if (e.target.closest('.qty-dec')) setQty(idx, l.quantity - 1);
    else if (e.target.closest('.qty-inc')) setQty(idx, Math.min(99, l.quantity + 1));
    else if (e.target.closest('.line-remove')) setQty(idx, 0);
  });
  function openCart() {
    $('#cart-drawer').classList.remove('-translate-x-full');
    $('#drawer-backdrop').classList.remove('hidden');
  }
  function closeCart() {
    $('#cart-drawer').classList.add('-translate-x-full');
    $('#drawer-backdrop').classList.add('hidden');
  }
  $('#cart-button').addEventListener('click', openCart);
  $('#cart-close').addEventListener('click', closeCart);
  $('#drawer-backdrop').addEventListener('click', closeCart);

  // ---------- Checkout ----------
  function customerFieldsHtml(o = {}) {
    return `
      <div class="grid sm:grid-cols-2 gap-3">
        <label class="block"><span class="text-sm font-medium">الاسم الكامل *</span>
          <input name="customer_name" required maxlength="100" value="${esc(o.customer_name || '')}" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="مثال: سارة أحمد"></label>
        <label class="block"><span class="text-sm font-medium">رقم الهاتف</span>
          <input name="customer_phone" maxlength="30" value="${esc(o.customer_phone || '')}" class="mt-1 w-full border rounded-lg px-3 py-2 ltr" placeholder="+966 5x xxx xxxx"></label>
        <label class="block sm:col-span-2"><span class="text-sm font-medium">البريد الإلكتروني *</span>
          <input name="customer_email" type="email" required ${o.lockEmail ? 'readonly' : ''} value="${esc(o.customer_email || state.customerEmail)}" class="mt-1 w-full border rounded-lg px-3 py-2 ${o.lockEmail ? 'bg-slate-50 text-slate-500' : ''}" placeholder="name@example.com">
          <span class="text-xs text-slate-400">ستستخدمه لمتابعة طلبك وتعديله</span></label>
        <label class="block sm:col-span-2"><span class="text-sm font-medium">عنوان التوصيل *</span>
          <textarea name="shipping_address" required rows="2" maxlength="500" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="المدينة، الحي، الشارع، رقم المبنى">${esc(o.shipping_address || '')}</textarea></label>
        <label class="block sm:col-span-2"><span class="text-sm font-medium">ملاحظات على الطلب</span>
          <textarea name="notes" rows="2" maxlength="1000" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="أي تفاصيل إضافية للطلب كله">${esc(o.notes || '')}</textarea></label>
      </div>`;
  }

  $('#checkout-button').addEventListener('click', () => {
    closeCart();
    openModal(`
      <form id="checkout-form" class="p-6 space-y-4">
        <h2 class="text-2xl font-bold"><i class="fas fa-truck text-brand ml-2"></i>إتمام الطلب</h2>
        <p class="text-slate-500 text-sm">${cartCount()} عنصر · الإجمالي <strong class="text-brand-800">${money(cartTotal())}</strong></p>
        ${customerFieldsHtml()}
        <p id="checkout-error" class="text-red-600 text-sm hidden"></p>
        <div class="flex gap-2 justify-end pt-2">
          <button type="button" class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">إلغاء</button>
          <button type="submit" class="px-5 py-2 rounded-lg bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700">تأكيد الطلب</button>
        </div>
      </form>`);
    $('.modal-cancel').addEventListener('click', closeModal);
    $('#checkout-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(e.target).entries());
      payload.items = state.cart.map((l) => ({ id: l.id, quantity: l.quantity, sticker_type: l.sticker_type, sticker_size: l.sticker_size, notes: l.notes }));
      const err = $('#checkout-error');
      err.classList.add('hidden');
      const btn = e.target.querySelector('button[type=submit]');
      btn.disabled = true;
      try {
        const { data } = await axios.post('/api/orders', payload);
        state.customerEmail = payload.customer_email.trim().toLowerCase();
        localStorage.setItem('customer_email', state.customerEmail);
        state.cart = [];
        saveCart();
        openModal(`<div class="p-8 text-center space-y-3">
          <i class="fas fa-circle-check text-brand text-6xl"></i>
          <h2 class="text-2xl font-bold">تم استلام طلبك!</h2>
          <p class="text-slate-600">رقم طلبك</p>
          <p class="order-code text-3xl font-black text-brand-800 bg-brand-50 rounded-2xl py-3 select-all">${codeLabel(data.order_code)}</p>
          <p class="text-sm text-slate-500">الإجمالي ${money(data.total)} · احفظ الرقم لمتابعة الطلب أو تعديله</p>
          <div class="flex gap-2 justify-center pt-2">
            <button class="modal-cancel px-5 py-2 rounded-lg border">متابعة التسوق</button>
            <button id="goto-order" class="px-5 py-2 rounded-lg bg-gradient-to-l from-brand to-brand-dark text-white font-semibold">عرض الطلب</button>
          </div></div>`);
        $('.modal-cancel').addEventListener('click', closeModal);
        $('#goto-order').addEventListener('click', () => {
          closeModal();
          navigate('order', data.order_code);
        });
        loadStickers();
      } catch (ex) {
        err.textContent = ex.response?.data?.error || 'حدث خطأ ما. حاول مرة أخرى.';
        err.classList.remove('hidden');
        btn.disabled = false;
      }
    });
  });

  // ---------- Storefront ----------
  async function loadStickers() {
    const params = {};
    if (state.category !== 'All') params.category = state.category;
    if (state.search) params.q = state.search;
    const [{ data: s }, { data: c }] = await Promise.all([axios.get('/api/stickers', { params }), axios.get('/api/categories')]);
    state.stickers = s.stickers;
    state.categories = c.categories;
    if (state.view === 'shop') renderShop();
  }

  function renderShop() {
    app.innerHTML = `
      <section id="hero-section" class="rounded-3xl bg-gradient-to-bl from-brand-light via-brand to-brand-800 text-white p-8 sm:p-12 mb-8 shadow-xl shadow-brand/30 relative overflow-hidden">
        <div class="relative z-10 max-w-xl">
          <h1 class="text-3xl sm:text-5xl font-black leading-tight mb-3">باقات ملصقات لكل الأذواق</h1>
          <p class="text-white/90 text-lg mb-5">باقات مختارة من ملصقات الفينيل عالية الجودة للابتوب، القوارير، الدفاتر والمزيد. اختر النوع والقياس الذي يناسبك.</p>
          <a href="#catalog" class="inline-block bg-white text-brand-700 font-bold px-6 py-3 rounded-full hover:bg-brand-50 transition shadow-md">تسوّق الآن <i class="fas fa-arrow-down mr-1"></i></a>
        </div>
        <i class="fas fa-note-sticky absolute -left-6 -bottom-10 text-[14rem] text-white/15 -rotate-12"></i>
      </section>

      <section id="catalog">
        <div class="flex flex-col sm:flex-row gap-3 sm:items-center justify-between mb-5">
          <nav id="category-filter" class="flex flex-wrap gap-2" aria-label="التصنيفات">
            ${['All', ...state.categories]
              .map(
                (cat) => `<button data-cat="${esc(cat)}" class="px-4 py-1.5 rounded-full text-sm font-medium border transition ${
                  cat === state.category ? 'bg-gradient-to-l from-brand to-brand-dark text-white border-brand' : 'bg-white hover:bg-brand-50 border-brand-100 text-slate-700'
                }">${cat === 'All' ? 'الكل' : esc(cat)}</button>`
              )
              .join('')}
          </nav>
          <div class="relative">
            <i class="fas fa-search absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input id="search-input" value="${esc(state.search)}" placeholder="ابحث عن باقة..." class="pr-9 pl-3 py-2 rounded-full border border-slate-200 w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-brand-300 focus:border-brand">
          </div>
        </div>
        <div id="sticker-grid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          ${
            state.stickers.length === 0
              ? `<p class="col-span-full text-center text-slate-400 py-16"><i class="fas fa-box-open text-4xl mb-3 block"></i>لا توجد باقات مطابقة.</p>`
              : state.stickers.map(stickerCard).join('')
          }
        </div>
      </section>`;

    $('#category-filter').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-cat]');
      if (!btn) return;
      state.category = btn.dataset.cat;
      loadStickers();
    });
    let searchTimer;
    $('#search-input').addEventListener('input', (e) => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        state.search = e.target.value.trim();
        loadStickers().then(() => {
          const inp = $('#search-input');
          inp.focus();
          inp.setSelectionRange(inp.value.length, inp.value.length);
        });
      }, 300);
    });
    $('#sticker-grid').addEventListener('click', gridClick);
  }
  function gridClick(e) {
    const card = e.target.closest('.sticker-card');
    if (card) navigate('pack', Number(card.dataset.id));
  }

  function stickerCard(s) {
    const out = s.stock <= 0;
    return `
      <article data-id="${s.id}" class="sticker-card group bg-white rounded-2xl overflow-hidden shadow-sm border border-brand-100 flex flex-col cursor-pointer" title="عرض تفاصيل الباقة">
        <div class="sticker-img aspect-square flex items-center justify-center p-3 relative">
          <img src="${esc(s.image_url)}" alt="${esc(s.name)}" loading="lazy" class="max-h-full max-w-full object-contain drop-shadow">
          <span class="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-white/90 text-brand-700 text-[11px] font-bold shadow-sm"><i class="fas fa-layer-group ml-1"></i>باقة</span>
          ${out ? '<span class="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-red-500 text-white text-[11px] font-bold">نفذت الكمية</span>' : ''}
          <span class="absolute inset-x-0 bottom-0 py-1.5 text-center text-xs font-semibold text-white bg-brand-800/80 opacity-0 group-hover:opacity-100 transition">عرض التفاصيل واختيار النوع والقياس</span>
        </div>
        <div class="p-4 flex flex-col flex-1">
          <span class="text-xs text-brand font-semibold">${esc(s.category)}</span>
          <h3 class="font-bold text-lg leading-snug group-hover:text-brand-700 transition">${esc(s.name)}</h3>
          <p class="text-sm text-slate-500 line-clamp-2 flex-1 mt-1">${esc(s.description)}</p>
          <div class="flex items-center justify-between mt-3">
            <span class="text-xl font-black text-brand-800">${money(s.price)}</span>
            <span class="px-3 py-1.5 rounded-full bg-brand-50 text-brand-800 text-sm font-semibold"><i class="fas fa-sliders ml-1"></i>خصّص</span>
          </div>
        </div>
      </article>`;
  }

  // Expose for the other modules (admin.js, orders)
  window.__shop = {
    state, $, esc, money, fmtDate, toast, openModal, closeModal, navigate, loadStickers, app,
    typeOf, sizeOf, statusOf, statusBadge, codeLabel, optionsHtml, bindOptions, optionsSummary, customerFieldsHtml,
    addToCart, openCart, stickerCard, gridClick, STATUS_CLASSES
  };
  window.__shop.checkAdmin = checkAdmin;
  window.__shop.openLoginModal = openLoginModal;

  // ---------- Admin auth ----------
  async function checkAdmin() {
    try {
      const { data } = await axios.get('/api/admin/me');
      state.isAdmin = data.isAdmin;
    } catch {
      state.isAdmin = false;
    }
    $('#admin-button').classList.toggle('hidden', !state.isAdmin);
    $('#admin-button').classList.toggle('flex', state.isAdmin);
    $('#admin-login-link').classList.toggle('hidden', state.isAdmin);
  }
  function openLoginModal() {
    openModal(`
      <form id="login-form" class="p-6 space-y-4">
        <h2 class="text-2xl font-bold"><i class="fas fa-user-shield text-brand-700 ml-2"></i>دخول المشرف</h2>
        <label class="block"><span class="text-sm font-medium">كلمة المرور</span>
          <input name="password" type="password" required autofocus class="mt-1 w-full border rounded-lg px-3 py-2 ltr"></label>
        <p id="login-error" class="text-red-600 text-sm hidden"></p>
        <div class="flex gap-2 justify-end">
          <button type="button" class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">إلغاء</button>
          <button type="submit" class="px-5 py-2 rounded-lg bg-brand-800 text-white font-semibold hover:bg-brand-900">تسجيل الدخول</button>
        </div>
      </form>`);
    $('.modal-cancel').addEventListener('click', closeModal);
    $('#login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await axios.post('/api/admin/login', { password: new FormData(e.target).get('password') });
        closeModal();
        await checkAdmin();
        toast('أهلاً بك أيها المشرف!');
        navigate('admin');
      } catch (ex) {
        const err = $('#login-error');
        err.textContent = ex.response?.data?.error || 'فشل تسجيل الدخول.';
        err.classList.remove('hidden');
      }
    });
  }
  $('#admin-login-link').addEventListener('click', openLoginModal);
  $('#admin-button').addEventListener('click', () => navigate('admin'));
  $('#my-orders-button').addEventListener('click', () => navigate('orders'));
  $('#brand-link').addEventListener('click', (e) => {
    e.preventDefault();
    navigate('shop');
  });

  // ---------- Render dispatcher ----------
  async function render() {
    if (state.view === 'admin') {
      if (!state.isAdmin) {
        app.innerHTML = `<section class="text-center py-24">
          <i class="fas fa-lock text-5xl text-brand-200 mb-4"></i>
          <h1 class="text-2xl font-bold mb-2">للمشرفين فقط</h1>
          <p class="text-slate-500 mb-6">سجّل الدخول لإدارة باقات الملصقات والطلبات.</p>
          <button id="admin-login-cta" class="px-6 py-3 rounded-full bg-brand-800 text-white font-semibold hover:bg-brand-900">دخول المشرف</button></section>`;
        $('#admin-login-cta').addEventListener('click', openLoginModal);
        return;
      }
      window.renderAdmin();
    } else if (state.view === 'pack') window.renderPackDetails();
    else if (state.view === 'orders') window.renderMyOrders();
    else if (state.view === 'order') window.renderOrderDetails();
    else renderShop();
  }
  window.__shop.render = render;

  // ---------- Init ----------
  $('#footer-year').textContent = new Date().getFullYear();
  renderCartBadge();
  renderCart();
  (async () => {
    const [{ data: opts }] = await Promise.all([axios.get('/api/options'), checkAdmin()]);
    state.options = opts;
    await loadStickers();
    render();
  })();
})();
