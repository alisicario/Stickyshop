/* ستيكي شوب — لوحة المشرف: إدارة الباقات (إضافة/تعديل/حذف) والطلبات */
(() => {
  const S = () => window.__shop;
  const TARGET_BYTES = 1024 * 1024; // compress uploads down to ~1 MB
  const fmtSize = (b) => (b >= 1024 * 1024 ? (b / 1024 / 1024).toFixed(2) + ' م.ب' : Math.round(b / 1024) + ' ك.ب');

  window.renderAdmin = async function renderAdmin() {
    const { state, $, app } = S();
    app.innerHTML = `
      <section id="admin-panel">
        <header class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h1 class="text-3xl font-black"><i class="fas fa-user-shield text-brand ml-2"></i>لوحة المشرف</h1>
            <p class="text-slate-500 text-sm">إدارة باقات الملصقات والطلبات.</p>
          </div>
          <div class="flex gap-2">
            <button id="add-sticker-button" class="px-4 py-2 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700 shadow-md shadow-brand/30"><i class="fas fa-plus ml-1"></i>إضافة باقة</button>
            <button id="logout-button" class="px-4 py-2 rounded-full border hover:bg-slate-50"><i class="fas fa-right-from-bracket ml-1"></i>خروج</button>
          </div>
        </header>
        <nav id="admin-tabs" class="flex gap-2 border-b mb-5">
          ${[
            ['packs', 'الباقات', 'fa-layer-group'],
            ['orders', 'الطلبات', 'fa-receipt']
          ]
            .map(
              ([t, label, icon]) => `<button data-tab="${t}" class="px-4 py-2 font-semibold border-b-2 -mb-px ${
                state.adminTab === t ? 'border-brand text-brand-700' : 'border-transparent text-slate-500 hover:text-brand-700'
              }"><i class="fas ${icon} ml-1"></i>${label}</button>`
            )
            .join('')}
        </nav>
        <div id="admin-content"><p class="text-slate-400 py-10 text-center"><i class="fas fa-spinner fa-spin ml-2"></i>جارٍ التحميل...</p></div>
      </section>`;

    $('#add-sticker-button').addEventListener('click', () => openStickerForm());
    $('#logout-button').addEventListener('click', async () => {
      await axios.post('/api/admin/logout');
      await S().checkAdmin();
      S().toast('تم تسجيل الخروج');
      S().navigate('shop');
    });
    $('#admin-tabs').addEventListener('click', (e) => {
      const b = e.target.closest('[data-tab]');
      if (!b) return;
      state.adminTab = b.dataset.tab;
      renderAdmin();
    });
    if (state.adminTab === 'orders') await renderOrders();
    else await renderStickerTable();
  };

  async function handleAuthError(ex) {
    if (ex.response?.status === 401) {
      await S().checkAdmin();
      S().toast('انتهت الجلسة. يرجى تسجيل الدخول مجدداً.', true);
      S().navigate('shop');
      return true;
    }
    return false;
  }

  // ---------- Packs table ----------
  async function renderStickerTable() {
    const { $, esc, money } = S();
    let stickers;
    try {
      ({ data: { stickers } } = await axios.get('/api/admin/stickers'));
    } catch (ex) {
      if (await handleAuthError(ex)) return;
      throw ex;
    }
    const box = $('#admin-content');
    if (stickers.length === 0) {
      box.innerHTML = `<p class="text-center text-slate-400 py-16"><i class="fas fa-box-open text-4xl mb-3 block"></i>لا توجد باقات بعد. اضغط "إضافة باقة" لإنشاء أول باقة!</p>`;
      return;
    }
    box.innerHTML = `
      <div class="overflow-x-auto bg-white rounded-2xl border shadow-sm">
        <table id="sticker-table" class="w-full text-sm">
          <thead class="bg-brand-50 text-right text-brand-800">
            <tr><th class="p-3">الباقة</th><th class="p-3">التصنيف</th><th class="p-3">السعر</th><th class="p-3">المخزون</th><th class="p-3">الحالة</th><th class="p-3 text-left">إجراءات</th></tr>
          </thead>
          <tbody>
            ${stickers
              .map(
                (s) => `
              <tr class="border-t" data-id="${s.id}">
                <td class="p-3"><div class="flex items-center gap-3">
                  <img src="${esc(s.image_url)}" alt="" class="w-12 h-12 rounded-lg object-contain sticker-img border">
                  <div><p class="font-semibold">${esc(s.name)} ${
                    s.detail_image_url
                      ? '<i class="fas fa-layer-group text-brand text-xs mr-1" title="تحتوي صورة المحتويات"></i>'
                      : '<i class="fas fa-triangle-exclamation text-amber-400 text-xs mr-1" title="لا توجد صورة محتويات بعد"></i>'
                  }</p><p class="text-slate-400 text-xs truncate max-w-[220px]">${esc(s.description)}</p></div></div></td>
                <td class="p-3">${esc(s.category)}</td>
                <td class="p-3 font-medium">${money(s.price)}</td>
                <td class="p-3 ${s.stock <= 5 ? 'text-red-600 font-semibold' : ''}">${s.stock}</td>
                <td class="p-3"><button class="toggle-active px-2 py-1 rounded-full text-xs font-semibold ${
                  s.is_active ? 'bg-brand-100 text-brand-800' : 'bg-slate-200 text-slate-600'
                }">${s.is_active ? 'ظاهرة' : 'مخفية'}</button></td>
                <td class="p-3 text-left whitespace-nowrap">
                  <button class="view-btn px-3 py-1.5 rounded-lg border hover:bg-slate-50" title="عرض في المتجر"><i class="fas fa-eye"></i></button>
                  <button class="edit-btn px-3 py-1.5 rounded-lg border hover:bg-slate-50 mr-1" title="تعديل"><i class="fas fa-pen"></i></button>
                  <button class="delete-btn px-3 py-1.5 rounded-lg border text-red-600 hover:bg-red-50 mr-1" title="حذف"><i class="fas fa-trash"></i></button>
                </td>
              </tr>`
              )
              .join('')}
          </tbody>
        </table>
      </div>`;

    $('#sticker-table').addEventListener('click', async (e) => {
      const row = e.target.closest('tr[data-id]');
      if (!row) return;
      const id = Number(row.dataset.id);
      const sticker = stickers.find((s) => s.id === id);
      if (e.target.closest('.view-btn')) S().navigate('pack', id);
      else if (e.target.closest('.edit-btn')) openStickerForm(sticker);
      else if (e.target.closest('.delete-btn')) confirmDelete(sticker);
      else if (e.target.closest('.toggle-active')) {
        try {
          await axios.put(`/api/admin/stickers/${id}`, { is_active: !sticker.is_active });
          S().toast(sticker.is_active ? 'تم إخفاء الباقة من المتجر' : 'الباقة ظاهرة الآن');
          renderStickerTable();
          S().loadStickers();
        } catch (ex) {
          if (!(await handleAuthError(ex))) S().toast(ex.response?.data?.error || 'فشل التحديث', true);
        }
      }
    });
  }

  // ---------- Image compression (client-side, target ≤ 1 MB) ----------
  // PNG/WebP with transparency → WebP (keeps alpha). JPEG/opaque → JPEG. SVG/GIF are left as-is if small enough.
  async function compressImage(file, onStatus) {
    if (file.size <= TARGET_BYTES && file.type !== 'image/png') return file; // already small enough (PNG is still re-encoded to shrink)
    if (file.type === 'image/svg+xml' || file.type === 'image/gif') return file;

    const bitmap = await loadBitmap(file);
    const hasAlpha = file.type === 'image/png' || file.type === 'image/webp' || file.type === 'image/avif';
    const outType = hasAlpha ? 'image/webp' : 'image/jpeg';
    const ext = hasAlpha ? 'webp' : 'jpg';

    let { width, height } = bitmap;
    const maxDim = 2400; // plenty for product photos
    if (Math.max(width, height) > maxDim) {
      const r = maxDim / Math.max(width, height);
      width = Math.round(width * r);
      height = Math.round(height * r);
    }
    let quality = 0.9;
    let blob = null;
    for (let attempt = 0; attempt < 8; attempt++) {
      onStatus?.(`جارٍ ضغط الصورة… (محاولة ${attempt + 1})`);
      blob = await drawToBlob(bitmap, width, height, outType, quality);
      if (blob.size <= TARGET_BYTES) break;
      // Alternate between lowering quality and shrinking dimensions
      if (quality > 0.6) quality -= 0.1;
      else {
        width = Math.round(width * 0.85);
        height = Math.round(height * 0.85);
      }
    }
    if (bitmap.close) bitmap.close();
    if (!blob) return file;
    if (blob.size >= file.size && file.size <= TARGET_BYTES) return file; // compression didn't help; keep original
    const name = file.name.replace(/\.[^.]+$/, '') + '.' + ext;
    return new File([blob], name, { type: outType });
  }
  function loadBitmap(file) {
    if (window.createImageBitmap) return createImageBitmap(file).catch(() => loadViaImg(file));
    return loadViaImg(file);
  }
  function loadViaImg(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url);
        resolve(img);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('تعذّر قراءة الصورة'));
      };
      img.src = url;
    });
  }
  function drawToBlob(bitmap, w, h, type, quality) {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0, w, h);
    return new Promise((resolve) => canvas.toBlob((b) => resolve(b), type, quality));
  }

  // ---------- Image field (preview + upload + URL) ----------
  function imageFieldHtml(id, label, hint, value, required) {
    const { esc } = S();
    return `
      <fieldset class="border border-brand-100 rounded-xl p-4 space-y-3">
        <legend class="text-sm font-medium px-1">${label}${required ? ' *' : ''}</legend>
        <div class="flex gap-4 items-start">
          <div id="${id}-preview" class="sticker-img w-28 h-28 rounded-xl border flex items-center justify-center overflow-hidden shrink-0">
            ${value ? `<img src="${esc(value)}" class="max-w-full max-h-full object-contain">` : '<i class="fas fa-image text-3xl text-slate-300"></i>'}
          </div>
          <div class="flex-1 space-y-2 min-w-0">
            <p class="text-xs text-slate-500">${hint}</p>
            <label class="block cursor-pointer">
              <span class="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-brand text-white text-sm font-medium hover:bg-brand-dark"><i class="fas fa-upload"></i>رفع صورة</span>
              <input id="${id}-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/avif" class="hidden">
            </label>
            <div id="${id}-progress" class="hidden h-2 w-full rounded-full bg-brand-50 overflow-hidden"><div id="${id}-bar" class="h-full bg-brand transition-all" style="width:0%"></div></div>
            <p id="${id}-status" class="text-xs text-slate-400">PNG، JPG، WebP، GIF، AVIF أو SVG · سيتم ضغط الصورة تلقائياً إلى 1 م.ب. أو الصق رابطاً:</p>
            <input id="${id}-url" value="${esc(value || '')}" class="w-full border rounded-lg px-3 py-2 text-sm ltr" placeholder="https://example.com/image.png">
          </div>
        </div>
      </fieldset>`;
  }

  function bindImageField(id) {
    const { $, esc, toast } = S();
    let uploading = false;
    const preview = $(`#${id}-preview`);
    const urlInput = $(`#${id}-url`);
    const progress = $(`#${id}-progress`);
    const bar = $(`#${id}-bar`);
    const status = $(`#${id}-status`);
    const setPreview = (src) => {
      preview.innerHTML = src
        ? `<img src="${esc(src)}" class="max-w-full max-h-full object-contain" onerror="this.replaceWith(Object.assign(document.createElement('i'),{className:'fas fa-triangle-exclamation text-2xl text-red-400'}))">`
        : '<i class="fas fa-image text-3xl text-slate-300"></i>';
    };

    $(`#${id}-file`).addEventListener('change', async (e) => {
      const original = e.target.files[0];
      if (!original) return;
      if (original.size > 50 * 1024 * 1024) {
        toast('الصورة كبيرة جداً (الحد الأقصى 50 م.ب قبل الضغط)', true);
        e.target.value = '';
        return;
      }
      const localUrl = URL.createObjectURL(original);
      setPreview(localUrl);
      uploading = true;
      $('#save-sticker-button').disabled = true;
      progress.classList.remove('hidden');
      bar.style.width = '0%';
      status.classList.remove('text-red-600');
      try {
        status.textContent = `جارٍ تجهيز ${original.name} (${fmtSize(original.size)})…`;
        const file = await compressImage(original, (m) => (status.textContent = m));
        if (file.size > 10 * 1024 * 1024) throw new Error('تعذّر ضغط الصورة إلى حجم مناسب. جرّب صورة أصغر.');
        status.textContent = `جارٍ رفع الصورة (${fmtSize(file.size)})…`;
        const fd = new FormData();
        fd.append('file', file);
        const { data } = await axios.post('/api/admin/upload', fd, {
          onUploadProgress: (p) => {
            if (p.total) bar.style.width = Math.round((p.loaded / p.total) * 100) + '%';
          }
        });
        urlInput.value = data.url;
        setPreview(data.url);
        const saved = original.size - file.size;
        status.innerHTML = `<i class="fas fa-check text-brand ml-1"></i>تم الرفع (${fmtSize(data.size)}${saved > 0 ? ` · تم توفير ${fmtSize(saved)}` : ''}).`;
      } catch (ex) {
        if (await handleAuthError(ex)) return;
        status.textContent = ex.response?.data?.error || ex.message || 'فشل الرفع. حاول مرة أخرى.';
        status.classList.add('text-red-600');
        setPreview(urlInput.value.trim());
      } finally {
        uploading = false;
        $('#save-sticker-button').disabled = false;
        setTimeout(() => progress.classList.add('hidden'), 600);
        URL.revokeObjectURL(localUrl);
        e.target.value = '';
      }
    });
    urlInput.addEventListener('input', () => setPreview(urlInput.value.trim()));
    return { value: () => urlInput.value.trim(), uploading: () => uploading };
  }

  // ---------- Add / Edit pack form ----------
  function openStickerForm(sticker = null) {
    const { $, esc, openModal, closeModal, toast, state } = S();
    const isEdit = !!sticker;
    const cats = [...new Set([...state.categories, 'لطيف', 'حيوانات', 'كلاسيكي', 'ألعاب', 'اقتباسات', 'طبيعة', 'عام'])];
    openModal(
      `
      <form id="sticker-form" class="p-6 space-y-4">
        <h2 class="text-2xl font-bold">${isEdit ? '<i class="fas fa-pen text-brand ml-2"></i>تعديل الباقة' : '<i class="fas fa-plus text-brand ml-2"></i>إضافة باقة جديدة'}</h2>
        <div class="grid sm:grid-cols-2 gap-4">
          <label class="block sm:col-span-2"><span class="text-sm font-medium">اسم الباقة *</span>
            <input name="name" required maxlength="100" value="${esc(sticker?.name || '')}" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="مثال: باقة القطط الفضائية"></label>
          <label class="block sm:col-span-2"><span class="text-sm font-medium">الوصف</span>
            <textarea name="description" rows="3" maxlength="1000" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="ماذا تحتوي الباقة؟ الفكرة، عدد الملصقات، التفاصيل...">${esc(sticker?.description || '')}</textarea></label>
          <label class="block"><span class="text-sm font-medium">سعر الباقة ($) *</span>
            <input name="price" type="number" step="0.01" min="0" required value="${sticker ? sticker.price : ''}" class="mt-1 w-full border rounded-lg px-3 py-2" placeholder="9.99"></label>
          <label class="block"><span class="text-sm font-medium">المخزون (عدد الباقات)</span>
            <input name="stock" type="number" step="1" min="0" value="${sticker ? sticker.stock : 100}" class="mt-1 w-full border rounded-lg px-3 py-2"></label>
          <label class="block sm:col-span-2"><span class="text-sm font-medium">التصنيف</span>
            <input name="category" list="category-list" value="${esc(sticker?.category || 'عام')}" class="mt-1 w-full border rounded-lg px-3 py-2">
            <datalist id="category-list">${cats.map((c) => `<option value="${esc(c)}">`).join('')}</datalist></label>
        </div>

        ${imageFieldHtml('cover', 'صورة الغلاف', '<i class="fas fa-store text-brand ml-1"></i>تظهر على بطاقة الباقة في المتجر.', sticker?.image_url, true)}
        ${imageFieldHtml('detail', 'صورة محتويات الباقة', '<i class="fas fa-layer-group text-brand ml-1"></i>تظهر بحجم كبير في صفحة التفاصيل — صورة لكل الملصقات داخل الباقة. إن تُركت فارغة تُستخدم صورة الغلاف.', sticker?.detail_image_url, false)}

        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" ${!sticker || sticker.is_active ? 'checked' : ''} class="w-4 h-4"> ظاهرة في المتجر</label>
        <p id="form-error" class="text-red-600 text-sm hidden"></p>
        <div class="flex gap-2 justify-end pt-1">
          <button type="button" class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">إلغاء</button>
          <button type="submit" id="save-sticker-button" class="px-5 py-2 rounded-lg bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700 disabled:opacity-50">
            ${isEdit ? 'حفظ التعديلات' : 'إضافة الباقة'}</button>
        </div>
      </form>`,
      true
    );

    const cover = bindImageField('cover');
    const detail = bindImageField('detail');
    $('.modal-cancel').addEventListener('click', closeModal);
    $('#sticker-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const payload = {
        name: fd.get('name'),
        description: fd.get('description'),
        price: fd.get('price'),
        stock: fd.get('stock'),
        category: fd.get('category'),
        image_url: cover.value(),
        detail_image_url: detail.value(),
        is_active: fd.get('is_active') === 'on'
      };
      const err = $('#form-error');
      err.classList.add('hidden');
      if (cover.uploading() || detail.uploading()) return showErr('يرجى الانتظار حتى ينتهي رفع الصورة.');
      if (!payload.image_url) return showErr('يرجى رفع صورة الغلاف أو إدخال رابط لها.');
      const btn = $('#save-sticker-button');
      btn.disabled = true;
      try {
        if (isEdit) await axios.put(`/api/admin/stickers/${sticker.id}`, payload);
        else await axios.post('/api/admin/stickers', payload);
        closeModal();
        toast(isEdit ? 'تم تحديث الباقة' : 'تمت إضافة الباقة إلى المتجر!');
        await S().loadStickers();
        renderStickerTable();
      } catch (ex) {
        if (await handleAuthError(ex)) return;
        showErr(ex.response?.data?.error || 'فشل حفظ الباقة.');
        btn.disabled = false;
      }
      function showErr(m) {
        err.textContent = m;
        err.classList.remove('hidden');
      }
    });
  }

  function confirmDelete(sticker) {
    const { $, esc, openModal, closeModal, toast } = S();
    openModal(`<div class="p-6 space-y-4">
      <h2 class="text-xl font-bold text-red-600"><i class="fas fa-triangle-exclamation ml-2"></i>حذف الباقة؟</h2>
      <p>هل تريد حذف <strong>${esc(sticker.name)}</strong> نهائياً؟ لا يمكن التراجع. نصيحة: استخدم "مخفية" بدلاً من الحذف للحفاظ على سجل الطلبات.</p>
      <div class="flex gap-2 justify-end">
        <button class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">إلغاء</button>
        <button id="confirm-delete" class="px-5 py-2 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700">حذف</button>
      </div></div>`);
    $('.modal-cancel').addEventListener('click', closeModal);
    $('#confirm-delete').addEventListener('click', async () => {
      try {
        await axios.delete(`/api/admin/stickers/${sticker.id}`);
        closeModal();
        toast('تم حذف الباقة');
        await S().loadStickers();
        renderStickerTable();
      } catch (ex) {
        if (!(await handleAuthError(ex))) toast(ex.response?.data?.error || 'فشل الحذف', true);
      }
    });
  }

  // ---------- Orders ----------
  async function renderOrders() {
    const { $, esc, money, fmtDate, toast, state, statusOf, statusBadge, codeLabel, typeOf, sizeOf, STATUS_CLASSES } = S();
    let orders;
    try {
      ({ data: { orders } } = await axios.get('/api/admin/orders'));
    } catch (ex) {
      if (await handleAuthError(ex)) return;
      throw ex;
    }
    const box = $('#admin-content');
    if (orders.length === 0) {
      box.innerHTML = `<p class="text-center text-slate-400 py-16"><i class="fas fa-receipt text-4xl mb-3 block"></i>لا توجد طلبات بعد.</p>`;
      return;
    }
    const active = orders.filter((o) => o.status !== 'cancelled');
    const revenue = active.reduce((s, o) => s + o.total, 0);
    const counts = Object.fromEntries(state.options.statuses.map((s) => [s.id, orders.filter((o) => o.status === s.id).length]));

    box.innerHTML = `
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-5">
        <div class="bg-white rounded-2xl border p-3"><p class="text-slate-500 text-xs">الطلبات</p><p class="text-2xl font-black">${orders.length}</p></div>
        <div class="bg-white rounded-2xl border p-3"><p class="text-slate-500 text-xs">الإيرادات</p><p class="text-2xl font-black text-brand-800">${money(revenue)}</p></div>
        ${state.options.statuses
          .map(
            (s) => `<button data-filter="${s.id}" class="status-filter bg-white rounded-2xl border p-3 text-right hover:border-brand-300 transition"><p class="text-slate-500 text-xs"><i class="fas ${s.icon} ml-1"></i>${esc(s.label)}</p><p class="text-2xl font-black">${counts[s.id]}</p></button>`
          )
          .join('')}
      </div>
      <div class="flex items-center gap-2 mb-3 text-sm">
        <span class="text-slate-500">تصفية:</span>
        <button data-filter="" class="status-filter px-3 py-1 rounded-full bg-brand text-white font-semibold">الكل</button>
        <span id="filter-label" class="text-slate-500"></span>
      </div>
      <div id="orders-list" class="space-y-3">${orders.map(orderCard).join('')}</div>`;

    function orderCard(o) {
      const st = statusOf(o.status);
      return `
        <article class="bg-white rounded-2xl border p-4 ${o.status === 'cancelled' ? 'opacity-70' : ''}" data-id="${o.id}" data-status="${o.status}">
          <header class="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div class="flex items-center gap-2">
              <span class="order-code font-black text-brand-800 text-lg">${codeLabel(esc(o.order_code))}</span>
              <span class="text-slate-400 text-xs">${fmtDate(o.created_at)}</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-lg font-bold">${money(o.total)}</span>
              <select class="status-select text-xs font-bold rounded-full px-3 py-1.5 border-0 cursor-pointer ${STATUS_CLASSES[st.color] || ''}">
                ${state.options.statuses.map((s) => `<option value="${s.id}" ${s.id === o.status ? 'selected' : ''}>${esc(s.label)}</option>`).join('')}
              </select>
            </div>
          </header>
          <div class="grid sm:grid-cols-2 gap-3 text-sm">
            <div>
              <p><strong>${esc(o.customer_name)}</strong> · <span class="ltr inline-block">${esc(o.customer_email)}</span>${o.customer_phone ? ` · <span class="ltr inline-block">${esc(o.customer_phone)}</span>` : ''}</p>
              <p class="text-slate-500 whitespace-pre-line">${esc(o.shipping_address)}</p>
              ${o.notes ? `<p class="text-slate-500 mt-1"><i class="fas fa-comment-dots ml-1"></i>${esc(o.notes)}</p>` : ''}
            </div>
            <ul class="space-y-1.5">
              ${o.items
                .map(
                  (i) => `<li class="bg-brand-50/60 rounded-xl px-3 py-2">
                  <p class="font-semibold">${i.quantity} × ${esc(i.sticker_name)} <span class="text-slate-400 font-normal">(${money(i.unit_price)})</span></p>
                  <p class="text-xs text-brand-800">${esc(typeOf(i.sticker_type).label)} · ${esc(sizeOf(i.sticker_size).label)}</p>
                  ${i.notes ? `<p class="text-xs text-slate-600 mt-0.5 whitespace-pre-line"><i class="fas fa-comment-dots ml-1"></i>${esc(i.notes)}</p>` : ''}
                </li>`
                )
                .join('')}
            </ul>
          </div>
        </article>`;
    }

    box.querySelectorAll('.status-filter').forEach((b) =>
      b.addEventListener('click', () => {
        const f = b.dataset.filter;
        box.querySelectorAll('#orders-list article').forEach((a) => a.classList.toggle('hidden', !!f && a.dataset.status !== f));
        $('#filter-label').textContent = f ? `عرض: ${statusOf(f).label}` : '';
      })
    );
    $('#orders-list').addEventListener('change', async (e) => {
      const sel = e.target.closest('.status-select');
      if (!sel) return;
      const art = sel.closest('article');
      const id = Number(art.dataset.id);
      try {
        await axios.put(`/api/admin/orders/${id}`, { status: sel.value });
        toast(`تم تحديث حالة الطلب إلى "${statusOf(sel.value).label}"`);
        renderOrders();
        S().loadStickers();
      } catch (ex) {
        if (!(await handleAuthError(ex))) toast(ex.response?.data?.error || 'فشل التحديث', true);
      }
    });
  }
})();
