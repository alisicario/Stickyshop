/* ستيكي شوب — صفحة تفاصيل الباقة + صفحات الطلبات (طلباتي / متابعة الطلب / تعديل / إلغاء) */
(() => {
  const S = () => window.__shop;

  // ======================================================
  // Pack details (with type / size / notes options)
  // ======================================================
  window.renderPackDetails = async function renderPackDetails() {
    const { state, $, esc, money, app, navigate, openModal, toast, addToCart, openCart, optionsHtml, bindOptions, stickerCard, gridClick } = S();
    app.innerHTML = `<p class="text-center text-slate-400 py-24"><i class="fas fa-spinner fa-spin ml-2"></i>جارٍ تحميل الباقة...</p>`;
    let s = state.stickers.find((x) => x.id === state.packId);
    if (!s) {
      try {
        ({ data: { sticker: s } } = await axios.get(`/api/stickers/${state.packId}`));
      } catch {
        s = null;
      }
    }
    if (!s) {
      app.innerHTML = `<section class="text-center py-24">
        <i class="fas fa-box-open text-5xl text-brand-200 mb-4"></i>
        <h1 class="text-2xl font-bold mb-2">الباقة غير موجودة</h1>
        <p class="text-slate-500 mb-6">ربما تمت إزالة هذه الباقة.</p>
        <button id="back-to-shop" class="px-6 py-3 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold">العودة للمتجر</button></section>`;
      $('#back-to-shop').addEventListener('click', () => navigate('shop'));
      return;
    }
    const out = s.stock <= 0;
    const low = !out && s.stock <= 5;
    const hasDetail = !!s.detail_image_url;
    const images = hasDetail ? [s.detail_image_url, s.image_url] : [s.image_url];
    document.title = `${s.name} — ستيكي شوب`;

    app.innerHTML = `
      <nav class="text-sm text-slate-500 mb-5 flex items-center gap-2" aria-label="مسار التنقل">
        <button id="back-to-shop" class="hover:text-brand-700 flex items-center gap-1"><i class="fas fa-arrow-right"></i> كل الباقات</button>
        <span>/</span><span class="text-brand-700 font-medium">${esc(s.category)}</span>
        <span>/</span><span class="text-slate-800 truncate">${esc(s.name)}</span>
      </nav>

      <section id="pack-details" class="grid lg:grid-cols-2 gap-8 bg-white rounded-3xl border border-brand-100 shadow-lg shadow-brand/10 p-5 sm:p-8">
        <div>
          <figure id="pack-gallery" class="sticker-img rounded-2xl border border-brand-100 aspect-square flex items-center justify-center overflow-hidden relative">
            <img id="pack-main-image" src="${esc(images[0])}" alt="محتويات ${esc(s.name)}" class="max-w-full max-h-full object-contain p-2 cursor-zoom-in">
            <span class="absolute top-3 right-3 px-3 py-1 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white text-xs font-bold shadow"><i class="fas fa-layer-group ml-1"></i>باقة ملصقات</span>
          </figure>
          ${
            images.length > 1
              ? `<div id="pack-thumbs" class="flex gap-3 mt-4">
                  ${images
                    .map(
                      (src, i) => `<button data-src="${esc(src)}" class="pack-thumb sticker-img w-20 h-20 rounded-xl border-2 ${i === 0 ? 'border-brand' : 'border-brand-100'} overflow-hidden flex items-center justify-center hover:border-brand transition" title="${i === 0 ? 'محتويات الباقة' : 'الغلاف'}">
                        <img src="${esc(src)}" alt="" class="max-w-full max-h-full object-contain p-1"></button>`
                    )
                    .join('')}
                </div>
                <p class="text-xs text-slate-400 mt-2"><i class="fas fa-images ml-1"></i>الصورة الأولى تعرض كل ما بداخل الباقة · الثانية هي الغلاف.</p>`
              : ''
          }
          <ul id="pack-features" class="grid grid-cols-2 gap-2 mt-5 text-sm text-slate-600">
            <li class="flex items-center gap-2 bg-brand-50 rounded-xl px-3 py-2"><i class="fas fa-layer-group text-brand"></i>عدة ملصقات في كل باقة</li>
            <li class="flex items-center gap-2 bg-brand-50 rounded-xl px-3 py-2"><i class="fas fa-droplet text-brand"></i>فينيل عالي الجودة</li>
            <li class="flex items-center gap-2 bg-brand-50 rounded-xl px-3 py-2"><i class="fas fa-palette text-brand"></i>ألوان زاهية ودقة عالية</li>
            <li class="flex items-center gap-2 bg-brand-50 rounded-xl px-3 py-2"><i class="fas fa-hand-sparkles text-brand"></i>سهل التقشير</li>
          </ul>
        </div>

        <div class="flex flex-col">
          <span class="text-xs text-brand font-bold">${esc(s.category)}</span>
          <h1 class="text-3xl sm:text-4xl font-black leading-tight mt-1">${esc(s.name)}</h1>
          <div class="flex items-center gap-3 mt-3">
            <span class="text-3xl font-black text-brand-800">${money(s.price)}</span>
            <span class="text-sm text-slate-400">للباقة</span>
          </div>
          <p class="mt-2 text-sm font-medium ${out ? 'text-red-600' : low ? 'text-amber-600' : 'text-brand-700'}">
            <i class="fas ${out ? 'fa-circle-xmark' : 'fa-circle-check'} ml-1"></i>${out ? 'نفذت الكمية' : low ? `متبقٍ ${s.stock} فقط` : 'متوفر'}
          </p>
          <div class="mt-4">
            <h2 class="text-base font-bold text-slate-800 mb-1">عن هذه الباقة</h2>
            <p class="text-slate-600 whitespace-pre-line leading-relaxed">${esc(s.description) || 'باقة مختارة من ملصقات الفينيل عالية الجودة.'}</p>
          </div>

          <div class="mt-6 border-t border-brand-100 pt-5">
            ${optionsHtml('pack')}
          </div>

          <div class="mt-6 flex flex-col sm:flex-row gap-3">
            <div class="flex items-center border border-brand-200 rounded-full overflow-hidden self-start">
              <button id="qty-inc" class="w-11 h-11 hover:bg-brand-50 text-lg" aria-label="زيادة">+</button>
              <input id="qty-input" type="number" min="1" max="99" value="1" class="w-12 h-11 text-center font-semibold border-0" style="box-shadow:none">
              <button id="qty-dec" class="w-11 h-11 hover:bg-brand-50 text-lg" aria-label="تقليل">-</button>
            </div>
            <button id="pack-add-to-cart" ${out ? 'disabled' : ''} class="flex-1 h-11 px-6 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold hover:from-brand-dark hover:to-brand-700 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed shadow-md shadow-brand/30 transition">
              <i class="fas fa-shopping-bag ml-2"></i>${out ? 'نفذت الكمية' : 'أضف الباقة إلى السلة'}
            </button>
          </div>
          <p class="text-xs text-slate-400 mt-3"><i class="fas fa-truck ml-1"></i>تُشحن مسطّحة ومحمية · باقة رقم ${s.id}</p>
        </div>
      </section>

      ${relatedPacks(s)}`;

    const opts = bindOptions('pack');
    $('#back-to-shop').addEventListener('click', () => navigate('shop'));
    const qtyInput = $('#qty-input');
    const clamp = (n) => Math.min(99, Math.max(1, Number(n) || 1));
    $('#qty-dec').addEventListener('click', () => (qtyInput.value = clamp(qtyInput.value - 1)));
    $('#qty-inc').addEventListener('click', () => (qtyInput.value = clamp(Number(qtyInput.value) + 1)));
    qtyInput.addEventListener('change', () => (qtyInput.value = clamp(qtyInput.value)));
    $('#pack-add-to-cart').addEventListener('click', () => {
      const qty = clamp(qtyInput.value);
      addToCart(s, opts.value(), qty, true);
      toast(`تمت إضافة ${qty} × "${s.name}" إلى السلة`);
      openCart();
    });
    const thumbs = $('#pack-thumbs');
    if (thumbs) {
      thumbs.addEventListener('click', (e) => {
        const b = e.target.closest('.pack-thumb');
        if (!b) return;
        $('#pack-main-image').src = b.dataset.src;
        thumbs.querySelectorAll('.pack-thumb').forEach((t) => t.classList.replace('border-brand', 'border-brand-100'));
        b.classList.replace('border-brand-100', 'border-brand');
      });
    }
    $('#pack-main-image').addEventListener('click', (e) => {
      openModal(`<div class="p-2 bg-slate-900 rounded-2xl"><img src="${esc(e.target.src)}" alt="${esc(s.name)}" class="max-h-[85vh] w-full object-contain rounded-xl"></div>`, true);
    });
    const related = $('#related-grid');
    if (related) related.addEventListener('click', gridClick);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    function relatedPacks(current) {
      const rel = state.stickers.filter((x) => x.id !== current.id && x.category === current.category).slice(0, 4);
      const list = rel.length ? rel : state.stickers.filter((x) => x.id !== current.id).slice(0, 4);
      if (!list.length) return '';
      return `<section id="related-packs" class="mt-10">
        <h2 class="text-2xl font-black mb-4">${rel.length ? `باقات أخرى من ${esc(current.category)}` : 'قد يعجبك أيضاً'}</h2>
        <div id="related-grid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">${list.map(stickerCard).join('')}</div></section>`;
    }
  };

  // ======================================================
  // My orders (lookup by email)
  // ======================================================
  window.renderMyOrders = async function renderMyOrders() {
    const { state, $, esc, money, fmtDate, app, navigate, statusBadge, codeLabel } = S();
    app.innerHTML = `
      <section id="my-orders" class="max-w-3xl mx-auto">
        <h1 class="text-3xl font-black mb-1"><i class="fas fa-receipt text-brand ml-2"></i>طلباتي</h1>
        <p class="text-slate-500 mb-5">أدخل بريدك الإلكتروني لعرض طلباتك ومتابعة حالتها.</p>
        <form id="orders-lookup" class="flex flex-col sm:flex-row gap-2 mb-6">
          <input name="email" type="email" required value="${esc(state.customerEmail)}" placeholder="name@example.com" class="flex-1 border rounded-full px-4 py-3">
          <button class="px-6 py-3 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold"><i class="fas fa-search ml-1"></i>عرض الطلبات</button>
        </form>
        <details class="mb-6 text-sm text-slate-500">
          <summary class="cursor-pointer hover:text-brand-700">لديك رقم طلب؟ ابحث به مباشرة</summary>
          <form id="code-lookup" class="flex gap-2 mt-3">
            <input name="code" required placeholder="czs12" class="flex-1 border rounded-full px-4 py-2 ltr">
            <button class="px-5 py-2 rounded-full border border-brand-300 text-brand-800 font-semibold hover:bg-brand-50">متابعة</button>
          </form>
        </details>
        <div id="orders-result"></div>
      </section>`;

    const load = async (email) => {
      const box = $('#orders-result');
      box.innerHTML = `<p class="text-center text-slate-400 py-10"><i class="fas fa-spinner fa-spin ml-2"></i>جارٍ التحميل...</p>`;
      state.customerEmail = email.trim().toLowerCase();
      localStorage.setItem('customer_email', state.customerEmail);
      try {
        const { data } = await axios.get('/api/my-orders', { params: { email: state.customerEmail } });
        if (!data.orders.length) {
          box.innerHTML = `<p class="text-center text-slate-400 py-12"><i class="fas fa-box-open text-4xl mb-3 block"></i>لا توجد طلبات مرتبطة بهذا البريد.</p>`;
          return;
        }
        box.innerHTML = `<div class="space-y-3">${data.orders
          .map(
            (o) => `
          <article class="order-card bg-white rounded-2xl border border-brand-100 p-4 hover:border-brand-300 transition cursor-pointer" data-code="${esc(o.order_code)}">
            <header class="flex flex-wrap items-center justify-between gap-2">
              <span class="order-code font-black text-brand-800 text-lg">${codeLabel(esc(o.order_code))}</span>
              ${statusBadge(o.status)}
            </header>
            <p class="text-sm text-slate-500 mt-1">${fmtDate(o.created_at)} · ${o.items.reduce((s, i) => s + i.quantity, 0)} عنصر · <strong class="text-slate-800">${money(o.total)}</strong></p>
            <p class="text-xs text-slate-400 mt-1 truncate">${o.items.map((i) => `${i.quantity}× ${esc(i.sticker_name)}`).join('، ')}</p>
          </article>`
          )
          .join('')}</div>`;
        box.querySelectorAll('.order-card').forEach((c) => c.addEventListener('click', () => navigate('order', c.dataset.code)));
      } catch (ex) {
        box.innerHTML = `<p class="text-center text-red-600 py-8">${esc(ex.response?.data?.error || 'حدث خطأ.')}</p>`;
      }
    };
    $('#orders-lookup').addEventListener('submit', (e) => {
      e.preventDefault();
      load(new FormData(e.target).get('email'));
    });
    $('#code-lookup').addEventListener('submit', (e) => {
      e.preventDefault();
      const code = String(new FormData(e.target).get('code')).trim().replace(/^#/, '').toLowerCase();
      if (code) navigate('order', code);
    });
    if (state.customerEmail) load(state.customerEmail);
  };

  // ======================================================
  // Order details / tracking / edit / cancel
  // ======================================================
  window.renderOrderDetails = async function renderOrderDetails() {
    const { state, $, esc, money, fmtDate, app, navigate, statusOf, statusBadge, codeLabel, typeOf, sizeOf, toast, openModal, closeModal } = S();
    const code = state.orderCode;

    const askEmail = (msg = '') => {
      app.innerHTML = `
        <section class="max-w-md mx-auto text-center py-16">
          <i class="fas fa-envelope-open-text text-5xl text-brand-200 mb-4"></i>
          <h1 class="text-2xl font-bold mb-1">الطلب <span class="order-code text-brand-800">${codeLabel(esc(code))}</span></h1>
          <p class="text-slate-500 mb-5">أدخل البريد الإلكتروني المستخدم في الطلب لعرضه.</p>
          <form id="verify-form" class="flex flex-col gap-2">
            <input name="email" type="email" required value="${esc(state.customerEmail)}" placeholder="name@example.com" class="border rounded-full px-4 py-3">
            <button class="px-6 py-3 rounded-full bg-gradient-to-l from-brand to-brand-dark text-white font-semibold">عرض الطلب</button>
          </form>
          ${msg ? `<p class="text-red-600 text-sm mt-3">${esc(msg)}</p>` : ''}
          <button id="back-orders" class="mt-6 text-sm text-slate-500 hover:text-brand-700"><i class="fas fa-arrow-right ml-1"></i>العودة إلى طلباتي</button>
        </section>`;
      $('#verify-form').addEventListener('submit', (e) => {
        e.preventDefault();
        state.customerEmail = String(new FormData(e.target).get('email')).trim().toLowerCase();
        localStorage.setItem('customer_email', state.customerEmail);
        load();
      });
      $('#back-orders').addEventListener('click', () => navigate('orders'));
    };

    const load = async () => {
      if (!state.customerEmail) return askEmail();
      app.innerHTML = `<p class="text-center text-slate-400 py-24"><i class="fas fa-spinner fa-spin ml-2"></i>جارٍ تحميل الطلب...</p>`;
      try {
        const { data } = await axios.get(`/api/orders/${encodeURIComponent(code)}`, { params: { email: state.customerEmail } });
        show(data.order, data.canEdit);
      } catch (ex) {
        askEmail(ex.response?.data?.error || 'حدث خطأ.');
      }
    };

    const show = (o, canEdit) => {
      const steps = state.options.statuses.filter((s) => s.id !== 'cancelled');
      const cancelled = o.status === 'cancelled';
      const curIdx = steps.findIndex((s) => s.id === o.status);
      document.title = `طلب ${codeLabel(o.order_code)} — ستيكي شوب`;

      app.innerHTML = `
        <nav class="text-sm text-slate-500 mb-5 flex items-center gap-2">
          <button id="back-orders" class="hover:text-brand-700 flex items-center gap-1"><i class="fas fa-arrow-right"></i> طلباتي</button>
          <span>/</span><span class="order-code text-slate-800">${codeLabel(esc(o.order_code))}</span>
        </nav>

        <section id="order-details" class="bg-white rounded-3xl border border-brand-100 shadow-lg shadow-brand/10 p-5 sm:p-8 space-y-6">
          <header class="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p class="text-sm text-slate-500">رقم الطلب</p>
              <h1 class="order-code text-3xl font-black text-brand-800">${codeLabel(esc(o.order_code))}</h1>
              <p class="text-xs text-slate-400 mt-1">أُنشئ ${fmtDate(o.created_at)}${o.updated_at && o.updated_at !== o.created_at ? ` · آخر تحديث ${fmtDate(o.updated_at)}` : ''}</p>
            </div>
            <div class="text-left">${statusBadge(o.status)}<p class="text-2xl font-black mt-2">${money(o.total)}</p></div>
          </header>

          <!-- Status timeline -->
          <div id="status-timeline" class="${cancelled ? 'opacity-60' : ''}">
            <div class="flex items-center">
              ${steps
                .map(
                  (s, i) => `
                <div class="status-step flex flex-col items-center ${i < curIdx ? 'done' : i === curIdx ? 'current' : ''}" style="min-width:64px">
                  <div class="status-dot"><i class="fas ${s.icon}"></i></div>
                  <span class="text-[11px] sm:text-xs mt-2 font-semibold ${i === curIdx ? 'text-brand-800' : i < curIdx ? 'text-brand' : 'text-slate-400'} text-center">${esc(s.label)}</span>
                </div>${i < steps.length - 1 ? `<div class="status-line ${i < curIdx ? 'done' : ''} mb-6"></div>` : ''}`
                )
                .join('')}
            </div>
            ${cancelled ? `<p class="mt-4 text-center text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl py-2"><i class="fas fa-circle-xmark ml-1"></i>تم إلغاء هذا الطلب</p>` : ''}
          </div>

          <!-- Items -->
          <div>
            <h2 class="font-bold text-lg mb-3"><i class="fas fa-layer-group text-brand ml-1"></i>العناصر</h2>
            <ul class="divide-y divide-brand-50 border border-brand-100 rounded-2xl overflow-hidden">
              ${o.items
                .map(
                  (i) => `<li class="p-4 flex flex-wrap items-start justify-between gap-2 bg-white">
                  <div class="min-w-0">
                    <p class="font-semibold">${i.quantity} × ${esc(i.sticker_name)}</p>
                    <p class="text-xs mt-1 flex flex-wrap gap-1">
                      <span class="px-2 py-0.5 rounded-full bg-brand-50 text-brand-800">${esc(typeOf(i.sticker_type).label)}</span>
                      <span class="px-2 py-0.5 rounded-full bg-brand-50 text-brand-800">${esc(sizeOf(i.sticker_size).label)}</span>
                    </p>
                    ${i.notes ? `<p class="text-xs text-slate-500 mt-1 whitespace-pre-line"><i class="fas fa-comment-dots ml-1"></i>${esc(i.notes)}</p>` : ''}
                  </div>
                  <span class="font-bold text-slate-700">${money(i.unit_price * i.quantity)}</span>
                </li>`
                )
                .join('')}
            </ul>
          </div>

          <!-- Customer -->
          <div class="grid sm:grid-cols-2 gap-4 text-sm">
            <div class="bg-brand-50/60 rounded-2xl p-4"><p class="text-slate-500 mb-1">بيانات العميل</p>
              <p class="font-semibold">${esc(o.customer_name)}</p><p class="ltr text-right text-slate-600">${esc(o.customer_email)}</p>${o.customer_phone ? `<p class="ltr text-right text-slate-600">${esc(o.customer_phone)}</p>` : ''}</div>
            <div class="bg-brand-50/60 rounded-2xl p-4"><p class="text-slate-500 mb-1">عنوان التوصيل</p><p class="whitespace-pre-line">${esc(o.shipping_address)}</p>
              ${o.notes ? `<p class="text-slate-500 mt-2"><i class="fas fa-comment-dots ml-1"></i>${esc(o.notes)}</p>` : ''}</div>
          </div>

          <!-- Actions -->
          ${
            canEdit
              ? `<footer class="flex flex-col sm:flex-row gap-3 border-t border-brand-100 pt-5">
                  <p class="text-xs text-slate-500 flex-1 self-center"><i class="fas fa-circle-info text-brand ml-1"></i>يمكنك تعديل أو إلغاء الطلب ما دام في مرحلة "${esc(statusOf(state.options.editableStatus).label)}".</p>
                  <button id="edit-order" class="px-5 py-2.5 rounded-full border-2 border-brand text-brand-800 font-semibold hover:bg-brand-50"><i class="fas fa-pen ml-1"></i>تعديل الطلب</button>
                  <button id="cancel-order" class="px-5 py-2.5 rounded-full border-2 border-red-200 text-red-600 font-semibold hover:bg-red-50"><i class="fas fa-ban ml-1"></i>إلغاء الطلب</button>
                </footer>`
              : cancelled
              ? ''
              : `<p class="text-xs text-slate-400 border-t border-brand-100 pt-4"><i class="fas fa-lock ml-1"></i>تجاوز الطلب مرحلة التصميم، لذا لم يعد بالإمكان تعديله أو إلغاؤه. تواصل معنا لأي استفسار.</p>`
          }
        </section>`;

      $('#back-orders').addEventListener('click', () => navigate('orders'));
      if (canEdit) {
        $('#edit-order').addEventListener('click', () => openEditForm(o));
        $('#cancel-order').addEventListener('click', () => {
          openModal(`<div class="p-6 space-y-4">
            <h2 class="text-xl font-bold text-red-600"><i class="fas fa-triangle-exclamation ml-2"></i>إلغاء الطلب ${codeLabel(esc(o.order_code))}؟</h2>
            <p class="text-slate-600">سيتم إلغاء الطلب نهائياً ولا يمكن التراجع عن ذلك.</p>
            <div class="flex gap-2 justify-end">
              <button class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">تراجع</button>
              <button id="confirm-cancel" class="px-5 py-2 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700">نعم، ألغِ الطلب</button>
            </div></div>`);
          $('.modal-cancel').addEventListener('click', closeModal);
          $('#confirm-cancel').addEventListener('click', async () => {
            try {
              const { data } = await axios.post(`/api/orders/${encodeURIComponent(code)}/cancel`, { customer_email: state.customerEmail });
              closeModal();
              toast('تم إلغاء الطلب');
              show(data.order, data.canEdit);
              S().loadStickers();
            } catch (ex) {
              closeModal();
              toast(ex.response?.data?.error || 'تعذّر إلغاء الطلب', true);
              load();
            }
          });
        });
      }
    };

    // ---- Edit form: items (qty + options) and shipping details ----
    const openEditForm = (o) => {
      const { optionsHtml, bindOptions, customerFieldsHtml } = S();
      const items = o.items.map((i) => ({ ...i }));
      openModal(
        `
        <form id="edit-order-form" class="p-6 space-y-5">
          <h2 class="text-2xl font-bold"><i class="fas fa-pen text-brand ml-2"></i>تعديل الطلب <span class="order-code text-brand-800">${codeLabel(esc(o.order_code))}</span></h2>

          <section>
            <h3 class="font-bold mb-2">العناصر</h3>
            <div id="edit-items" class="space-y-4">
              ${items
                .map(
                  (i, idx) => `
                <details class="edit-item border border-brand-100 rounded-2xl" data-idx="${idx}" ${idx === 0 ? 'open' : ''}>
                  <summary class="flex items-center justify-between gap-3 p-4 cursor-pointer">
                    <span class="font-semibold">${esc(i.sticker_name)} <span class="text-slate-400 text-sm">(${money(i.unit_price)})</span></span>
                    <span class="flex items-center gap-2" onclick="event.preventDefault()">
                      <button type="button" class="qty-inc w-8 h-8 rounded-full bg-brand-50 hover:bg-brand-100">+</button>
                      <input type="number" class="qty-input w-12 h-8 text-center border rounded-lg" min="1" max="99" value="${i.quantity}">
                      <button type="button" class="qty-dec w-8 h-8 rounded-full bg-brand-50 hover:bg-brand-100">-</button>
                      <button type="button" class="item-remove w-8 h-8 rounded-full text-red-500 hover:bg-red-50" title="حذف"><i class="fas fa-trash"></i></button>
                    </span>
                  </summary>
                  <div class="px-4 pb-4">${optionsHtml(`edit${idx}`, i)}</div>
                </details>`
                )
                .join('')}
            </div>
            <p id="edit-items-empty" class="hidden text-sm text-red-600 mt-2">يجب أن يحتوي الطلب على عنصر واحد على الأقل. لإلغاء الطلب كاملاً استخدم زر "إلغاء الطلب".</p>
          </section>

          <section>
            <h3 class="font-bold mb-2">بيانات التوصيل</h3>
            ${customerFieldsHtml({ ...o, lockEmail: true })}
          </section>

          <p id="edit-error" class="text-red-600 text-sm hidden"></p>
          <div class="flex gap-2 justify-end">
            <button type="button" class="modal-cancel px-4 py-2 rounded-lg border hover:bg-slate-50">إلغاء</button>
            <button type="submit" class="px-5 py-2 rounded-lg bg-gradient-to-l from-brand to-brand-dark text-white font-semibold">حفظ التعديلات</button>
          </div>
        </form>`,
        true
      );
      const binders = items.map((_, idx) => bindOptions(`edit${idx}`));
      const removed = new Set();
      $('.modal-cancel').addEventListener('click', closeModal);
      $('#edit-items').addEventListener('click', (e) => {
        const el = e.target.closest('.edit-item');
        if (!el) return;
        const inp = el.querySelector('.qty-input');
        const clamp = (n) => Math.min(99, Math.max(1, Number(n) || 1));
        if (e.target.closest('.qty-inc')) inp.value = clamp(Number(inp.value) + 1);
        else if (e.target.closest('.qty-dec')) inp.value = clamp(inp.value - 1);
        else if (e.target.closest('.item-remove')) {
          removed.add(Number(el.dataset.idx));
          el.remove();
          $('#edit-items-empty').classList.toggle('hidden', removed.size < items.length);
        }
      });
      $('#edit-order-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const err = $('#edit-error');
        err.classList.add('hidden');
        const payload = Object.fromEntries(new FormData(e.target).entries());
        payload.customer_email = state.customerEmail;
        payload.items = items
          .map((i, idx) => {
            if (removed.has(idx)) return null;
            const el = document.querySelector(`.edit-item[data-idx="${idx}"]`);
            return { id: i.sticker_id, quantity: Number(el.querySelector('.qty-input').value) || 1, ...binders[idx].value() };
          })
          .filter(Boolean);
        if (!payload.items.length) {
          $('#edit-items-empty').classList.remove('hidden');
          return;
        }
        try {
          const { data } = await axios.put(`/api/orders/${encodeURIComponent(code)}`, payload);
          closeModal();
          toast('تم حفظ تعديلات الطلب');
          show(data.order, data.canEdit);
          S().loadStickers();
        } catch (ex) {
          err.textContent = ex.response?.data?.error || 'تعذّر حفظ التعديلات.';
          err.classList.remove('hidden');
        }
      });
    };

    load();
  };
})();
